package com.e_sppd_rssm;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import koneksi.Daftar_String;
import koneksi.JSONParser;
import koneksi.Koneksi;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.e_sppd.rssm.R;
public class Profil extends Activity implements OnClickListener {
	private static final String TAG = "Profil";
	private TextView nip_lokal,  update_nip, update_namapeg, update_jabatan,
			update_golongan, update_reg_pass;
	private Button btn_change,btn_batal, btn_update_pass;
	private ListView listView;
	private Koneksi Koneksi_Server;
	private Daftar_String selectedList;
	private List<Daftar_String> list;
	private List_Profils adapter;
	private ProgressDialog loading;
	private EditText update_reg_pass_ulangi;

	private static final String update_pass = "http://sppdrssm.rssoedonomadiun.co.id/sppd_rssm_apk/update_pass.php";
	private static final String TAG_BERHASIL = "sukses";
	private static final String TAG_PESAN = "pesan";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.list_profil);
		nip_lokal 			= (TextView) findViewById(R.id.nip_lokal);
		btn_change 			= (Button) findViewById(R.id.btn_change);
		btn_batal			= (Button) findViewById(R.id.btn_batal);
		btn_update_pass 	= (Button) findViewById(R.id.btn_update_pass);

		update_nip 				= (TextView) findViewById(R.id.update_nip);
		update_namapeg 			= (TextView) findViewById(R.id.update_namapeg);
		update_jabatan 			= (TextView) findViewById(R.id.update_jabatan);
		update_golongan 		= (TextView) findViewById(R.id.update_golongan);
		update_reg_pass 		= (TextView) findViewById(R.id.update_reg_pass);
		update_reg_pass_ulangi  = (EditText) findViewById(R.id.update_reg_pass_ulangi);

		Bundle b = getIntent().getExtras();
		String transfer_nip = b.getString("transfer_nip");
		String nama_pegawai = b.getString("transfer_nama_pegawai");
		String jabatan = b.getString("transfer_jabatan");
		String golongan = b.getString("transfer_golongan");
		String password = b.getString("transfer_password");


		nip_lokal.setText(transfer_nip);
		update_nip.setText(transfer_nip);
		update_namapeg.setText(nama_pegawai);
		update_jabatan.setText(jabatan);
		update_golongan.setText(golongan);
		if (password.isEmpty()){
			update_reg_pass.setText(null);
		}else {
			update_reg_pass.setText("**************");
		}

	//	Koneksi_Server = new Koneksi();
	//	listView = (ListView) findViewById(R.id.list_profil_pegwai);

	//	list = new ArrayList<Daftar_String>();
	//	new MainActivityAsync().execute();


		btn_change.setOnClickListener(this);
		btn_update_pass.setOnClickListener(this);
		btn_batal.setOnClickListener(this);
	}


	public void aktif() {
		update_nip.setEnabled(false);
		update_namapeg.setEnabled(false);
		update_jabatan.setEnabled(false);
		update_golongan.setEnabled(false);
		update_reg_pass.setEnabled(false);

		update_reg_pass_ulangi.setVisibility(View.VISIBLE);
		btn_update_pass.setVisibility(View.VISIBLE);
		btn_batal.setVisibility(View.VISIBLE);
		btn_change.setVisibility(View.GONE);
	}
	public void batal() {
		update_nip.setEnabled(false);
		update_namapeg.setEnabled(false);
		update_jabatan.setEnabled(false);
		update_golongan.setEnabled(false);
		update_reg_pass.setEnabled(false);
		update_reg_pass_ulangi.setText("");
		update_reg_pass_ulangi.setVisibility(View.GONE);
		btn_update_pass.setVisibility(View.GONE);
		btn_batal.setVisibility(View.GONE);
		btn_change.setVisibility(View.VISIBLE);
	}

	public void kembali_activity(View view){
		super.onBackPressed();
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.btn_change:
			aktif();
			break;
		case R.id.btn_batal:
			batal();
			break;
		case R.id.btn_update_pass:

			if (update_reg_pass_ulangi.getText().toString().isEmpty()) {
					Toast.makeText(Profil.this,
							"... Password Tidak Boleh Kosong ...",
						Toast.LENGTH_LONG).show();
			} else if (update_reg_pass_ulangi.getText().toString().length() < 5) {
				Toast.makeText(Profil.this,
						"... Min. 5 Karakter ...",
						Toast.LENGTH_LONG).show();
			} else {
				new Proses_update_Pass().execute();
			}

			break;
		default:
		}
	}

	class Proses_update_Pass extends AsyncTask<String, String, String> {
		boolean failure = false;

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			loading = new ProgressDialog(Profil.this);
			loading.setMessage("Loading ...");
			loading.setIndeterminate(false);
			loading.setCancelable(false);
			loading.show();
		}

		@Override
		protected String doInBackground(String... args) {
			int berhasil;

			String nip_pegawai = nip_lokal.getText().toString().trim();
			String ambil_pass_baru = update_reg_pass_ulangi.getText()
					.toString().trim();

			try {

				List<NameValuePair> parameterNya = new ArrayList<NameValuePair>();
				parameterNya.add(new BasicNameValuePair("nip_pegawai",
						nip_pegawai));
				parameterNya.add(new BasicNameValuePair("ambil_pass_baru",
						ambil_pass_baru));

				Log.d("Request ke server!", "dimulai");
				JSONParser ambil_classJSONParser = new JSONParser();
				JSONObject jsonObjectNya = ambil_classJSONParser
						.makeHttpRequest(update_pass, "POST", parameterNya);
				Log.d("Try Again", jsonObjectNya.toString());
				berhasil = jsonObjectNya.getInt(TAG_BERHASIL);
				if (berhasil == 1) {
					Log.d("Sukses !!!", jsonObjectNya.toString());
					finish();
					return jsonObjectNya.getString(TAG_PESAN);
				} else {
					Log.d("Failed !!!", jsonObjectNya.getString(TAG_PESAN));
					return jsonObjectNya.getString(TAG_PESAN);
				}

			} catch (JSONException e) {
				e.printStackTrace();
			}
			return null;
		}

		@Override
		protected void onPostExecute(String url_registrasi_nya) {
			loading.dismiss();
			if (url_registrasi_nya != null) {
				Toast.makeText(Profil.this, url_registrasi_nya,
						Toast.LENGTH_LONG).show();
			}
		}
	}
/*
	private class MainActivityAsync extends AsyncTask<String, Void, String> {

		@Override
		protected void onPreExecute() {
			loading = new ProgressDialog(Profil.this);
			loading.setMessage("Proses Ambil Data . . .");
			loading.setIndeterminate(false);
			loading.setCancelable(false);
			loading.show();
		}

		@Override
		protected String doInBackground(String... params) {


			String nip_pegawai = nip_lokal.getText().toString().trim();

			String Cek = String.valueOf(nip_pegawai);
			String url;

			try {

				url = Koneksi_Server.sendGetRequest(Koneksi.profil_pegawai
						+ "?nip_pegawai=" + URLEncoder.encode(Cek, "UTF-8"));

				list = proses_pengambilan_data(url);
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			return null;
		}

		@Override
		protected void onPostExecute(String result) {
			loading.dismiss();
			runOnUiThread(new Runnable() {
				@Override
				public void run() {
					menampilkan_nama_pegawai();
				}
			});
		}

	}

	private List<Daftar_String> proses_pengambilan_data(String response) {
		List<Daftar_String> list_Daftar_String = new ArrayList<Daftar_String>();
		try {
			JSONObject jsonObj = new JSONObject(response);
			JSONArray jsonArray = jsonObj.getJSONArray("tampil_data");
			Log.d(TAG, "data lengt: " + jsonArray.length());
			Daftar_String mhs = null;
			for (int i = 0; i < jsonArray.length(); i++) {
				JSONObject obj = jsonArray.getJSONObject(i);
				mhs = new Daftar_String();
				mhs.setnip(obj.getString("nip"));
				mhs.setnama_pegawai(obj.getString("nama_pegawai"));
				mhs.setjabatan(obj.getString("jabatan"));
				mhs.setgolongan(obj.getString("golongan"));
				mhs.setpass(obj.getString("pass"));

				list_Daftar_String.add(mhs);
			}
		} catch (JSONException e) {

			if (e.getMessage() != null) {
				Log.d(TAG, e.getMessage());
			} else {
				Toast.makeText(Profil.this, "Gagal Mengambil Data",
						Toast.LENGTH_LONG).show();
			}

		}
		return list_Daftar_String;
	}

	private void menampilkan_nama_pegawai() {
		if (!terkoneksi(Profil.this)) {
			Toast.makeText(Profil.this, "Not Connected", Toast.LENGTH_LONG)
					.show();
			return;
		} else {
			adapter = new List_Profils(getApplicationContext(), list);
			listView.setAdapter(adapter);

			listView.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> adapterView, View v,
						int pos, long id) {
					selectedList = (Daftar_String) adapter.getItem(pos);
					tampil_data();

				}
			});
		}
	}
*/
	private void tampil_data() {

	//	update_nip.setText(selectedList.getnip());
	//	update_namapeg.setText(selectedList.getnama_pegawai());
	//	update_jabatan.setText(selectedList.getjabatan());
	//	update_golongan.setText(selectedList.getgolongan());
	//	update_reg_pass.setText(selectedList.getpass());
	}
}
