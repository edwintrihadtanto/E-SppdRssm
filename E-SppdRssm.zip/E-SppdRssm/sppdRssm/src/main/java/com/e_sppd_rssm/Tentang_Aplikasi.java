package com.e_sppd_rssm;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;

import koneksi.Java_Connection;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.widget.CardView;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import bantuan_tutorial.Tutorial_Ke2;
import koneksi.Koneksi;

import com.e_sppd.rssm.R;
public class Tentang_Aplikasi extends Activity {
	private TextView nip_lokal, tanggl_kritik, text_versi;
	private Button feedback, tutorial;
	private Handler handler = new Handler();
	//private static final String simpan_kritik = "http://sppdrssm.rssoedonomadiun.co.id/sppd_rssm_apk/simpan_kritik.php";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.tentang_apk);
		handler.postDelayed(runnable, 1000);

		nip_lokal = (TextView) findViewById(R.id.nip_lokal);
		tutorial = (Button) findViewById(R.id.tutorial);
		feedback = (Button) findViewById(R.id.feedback);
		tanggl_kritik = (TextView) findViewById(R.id.tgl_kritik);
		text_versi = (TextView) findViewById(R.id.text5);

		Bundle b = getIntent().getExtras();
		String transferan_nip = b.getString("transfer_nip");
		if (transferan_nip == null){
			Toast.makeText(Tentang_Aplikasi.this, "Nip : Null",
					Toast.LENGTH_LONG).show();
		}else{
			nip_lokal.setText(transferan_nip);
			//nip_lokal.setVisibility(View.VISIBLE);
		}
		String versi = b.getString("versi");

		text_versi.setText("versi " + versi);
		feedback.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				popUp();
			}
		});

		tutorial.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent i = null;
				i = new Intent(Tentang_Aplikasi.this, Tutorial_Ke2.class);
				startActivity(i);
			}
		});

	}

	private void popUp() {
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		dialog.setContentView(R.layout.dialog_pop_up);
		CardView cancel = (CardView) dialog.findViewById(R.id.btn_cncl);
		CardView save 	= (CardView) dialog.findViewById(R.id.btn_simpan);

		dialog.show();

		cancel.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				dialog.dismiss();
				Toast.makeText(Tentang_Aplikasi.this, "Batal Kritik dan Saran",
						Toast.LENGTH_LONG).show();
			}
		});

		save.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				EditText editkritik = (EditText) dialog.findViewById(R.id.editkritik);
				dialog.dismiss();
				String nip = nip_lokal.getText().toString().trim();
				String feedback = editkritik.getText().toString().trim();
				String tgl_kritik = tanggl_kritik.getText().toString().trim();

				if (feedback.toString().isEmpty()) {
					Toast.makeText(Tentang_Aplikasi.this,
							"Maaf Anda Belum Memberikan Kritik dan Saran",
							Toast.LENGTH_LONG).show();
				} else if (feedback.toString().length() > 150) {
					Toast.makeText(Tentang_Aplikasi.this,
							"Maks. Panjang Karakter 150", Toast.LENGTH_LONG)
							.show();
				} else {
					simpan_kritik(nip, feedback, tgl_kritik);
				}

			}
		});
	}

	private Runnable runnable = new Runnable() {

		@SuppressLint("SimpleDateFormat")
		@Override
		public void run() {
			// TODO Auto-generated method stub
			Calendar c1 = Calendar.getInstance();

			SimpleDateFormat tgl_skrng = new SimpleDateFormat("yyyy/M/d");
			SimpleDateFormat jam_skrng = new SimpleDateFormat("h:m:s");
			// SimpleDateFormat sdf1 = new SimpleDateFormat("d/M/yyyy h:m:s a");
			String strdate_tgl = tgl_skrng.format(c1.getTime());
			String strdate_jam = jam_skrng.format(c1.getTime());

			tanggl_kritik.setText(strdate_tgl + " " + strdate_jam);

			handler.postDelayed(this, 1000);
		}

	};

	private void simpan_kritik(String nip, String feedback, String tgl_kritik) {

		class Input_Baru extends AsyncTask<String, Void, String> {

			ProgressDialog tampilloading;
			Java_Connection ruc = new Java_Connection();

			@Override
			protected void onPreExecute() {
				super.onPreExecute();
				tampilloading = ProgressDialog.show(Tentang_Aplikasi.this, "",
						"Sedang Mengirim Kritik dan Saran...", true, true);
				tampilloading.setCancelable(false);
			}

			@Override
			protected void onPostExecute(String s) {
				super.onPostExecute(s);
				tampilloading.dismiss();
				Toast.makeText(Tentang_Aplikasi.this, "Terima Kasih Atas Kritik dan Saran Anda",
						Toast.LENGTH_LONG).show();
			}

			@Override
			protected String doInBackground(String... params) {
				HashMap<String, String> data = new HashMap<String, String>();
				data.put("nip", params[0]);
				data.put("feedback", params[1]);
				data.put("tgl_kritik", params[2]);

				String result = ruc.sendPostRequest(Koneksi.simpan_kritik, data);
				return result;

			}
		}

		Input_Baru ru = new Input_Baru();
		ru.execute(nip, feedback, tgl_kritik);
	}

	public void kembali_activity(View view){
		super.onBackPressed();
	}
}
