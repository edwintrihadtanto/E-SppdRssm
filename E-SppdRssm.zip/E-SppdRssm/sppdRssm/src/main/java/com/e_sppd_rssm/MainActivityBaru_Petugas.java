package com.e_sppd_rssm;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.e_sppd.rssm.R;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import koneksi.JSONParser;
import koneksi.Koneksi;

public class MainActivityBaru_Petugas extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    private Handler handler = new Handler();
    private final static String TAG = "Informasi_error";
    JSONParser classJsonParser = new JSONParser();
    Toolbar toolbar;
    DrawerLayout drawer;
    NavigationView navigationView;
    FragmentManager fragmentManager;
    Fragment fragment = null;
    SharedPreferences sharedpreferences;
    String nip, nama_pegawai, jabatan, golongan, password, cek_versi_apk;
    private ProgressDialog progresdialog;
    boolean doubleBackToExitPressedOnce = false;

    private TextView tgl_utama, jam_utama, menuutama_nippetugas, menuutama_namapetugas;
    public static final String TAG_NIP          = "nip";
    public static final String TAG_NAMA_PEGAWAI = "nama_pegawai";
    public final static String TAG_JABATAN 		= "jabatan";
    public final static String TAG_GOLONGAN 	= "golongan";
    public final static String TAG_PASSWORD 	= "password";
    private static final String TAG_SUKSES 		= "berhasil";
    private static final String TAG_PESAN 		= "tampilkan_pesan";
    private static final String Info_Pesan 		= "message";
    public static final String versi            = "versi";
    private static final int progress_DOWNLOAD 	= 0;
    String get_pesan;

    ConnectivityManager conMgr;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_petugas);
        handler.postDelayed(runnable, 1000);
      //  toolbar = (Toolbar) findViewById(R.id.toolbar);
      //  setSupportActionBar(toolbar);
        conMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        {
            if (conMgr.getActiveNetworkInfo() != null
                    && conMgr.getActiveNetworkInfo().isAvailable()
                    && conMgr.getActiveNetworkInfo().isConnected()) {
            } else {
                info_tak_ada_koneksi("Tidak Ada Koneksi Internet");
            }
        }
        menuutama_nippetugas    = (TextView )findViewById(R.id.menuutama_nippetugas);
        menuutama_namapetugas   = (TextView )findViewById(R.id.menuutama_namapetugas);
        tgl_utama               = (TextView )findViewById(R.id.tgl_utama);
        jam_utama               = (TextView )findViewById(R.id.jam_utama);

        sharedpreferences   = getSharedPreferences(Login_Activity.my_shared_preferences, Context.MODE_PRIVATE);
        nip                 = getIntent().getStringExtra(TAG_NIP);
        nama_pegawai        = getIntent().getStringExtra(TAG_NAMA_PEGAWAI);
        cek_versi_apk       = getIntent().getStringExtra(versi);
        jabatan             = getIntent().getStringExtra(TAG_JABATAN);
        golongan            = getIntent().getStringExtra(TAG_GOLONGAN);
        password            = getIntent().getStringExtra(TAG_PASSWORD);

        new Cek_Versi_APK().execute();

        menuutama_nippetugas.setText(nip);
        menuutama_namapetugas.setText(nama_pegawai);

        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
        //        this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
                this, drawer,  R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        // tampilan default awal ketika aplikasii dijalankan
        if (savedInstanceState == null) {
            // Intent(getActivity(), UmurActivity.class);
            //  getActivity().startActivity(intent);
            fragment = new Tampilan_Utama();
            callFragment(fragment);
            //Toast.makeText(MainActivityBaru_Admin.this, "Yess... Sukses",
             //       Toast.LENGTH_LONG).show();

        }
    }

    public class Cek_Versi_APK extends AsyncTask<String, String, String> {

        ProgressDialog loading;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            loading = new ProgressDialog(MainActivityBaru_Petugas.this);
            loading.setMessage("Loading Cek Versi... !!!");
            loading.setIndeterminate(false);
            loading.setCancelable(false);
            loading.show();
        }

        @Override
        protected String doInBackground(String... args) {
            int jikaSukses;

            //String Kirim_Cek_Versi_APK = cek_versi_apk.getText().toString();
            String responseString = null;
            try {

                List<NameValuePair> namaDanPassword = new ArrayList<NameValuePair>();
                namaDanPassword.add(new BasicNameValuePair("kirim_versi",
                        cek_versi_apk));
                Log.d("Proses Cek Versi!", "dimulai");

                JSONObject jsonObjectNya = classJsonParser.makeHttpRequest(
                        Koneksi.CEK_VERSI, "POST", namaDanPassword);

                // priksa log jawaban dari JSON
                Log.d("Coba login", jsonObjectNya.toString());

                // apa kata JSON tentang TAG_SUKSES
                // TAG_SUKSES = "berhasil";
                jikaSukses = jsonObjectNya.getInt(TAG_SUKSES);
                // cek_level = jsonObjectNya.getInt(Security_Level);

                if (jikaSukses == 1) {

                    Log.d("Versi Benar", jsonObjectNya.getString(TAG_PESAN));

                    return jsonObjectNya.getString(TAG_PESAN);

                } else {
                    //String Info_versi = jsonObjectNya.getString(TAG_VERSI_BARU);
                    Log.d("Perlu Versi Baru",jsonObjectNya.getString(TAG_PESAN));
                    get_pesan = jsonObjectNya.getString(Info_Pesan);
                    //menuutama_namapetugas.setText(get_pesan);
                    return jsonObjectNya.getString(TAG_PESAN);

                }
            } catch (JSONException e) {
                responseString = e.toString();
            } catch (Exception e){
                responseString = e.toString();
            }

            return responseString;

        }

        @Override
        protected void onPostExecute(String urlFileNya) {
            // kalau sudah selesai di gunakan, matikanlah
            // progressbar_nya dengan metode dismiss();
            loading.dismiss();
            if (urlFileNya != null) {
                if (urlFileNya.contains("Silahkan")){
                    download_informasi_versi(urlFileNya);
                }else if (urlFileNya.contains("Maintenance")){
                   // String pesan = "Sedang Dalam Maintenance Sistem ... !!!\nCobalah Beberapa Menit Lagi...";
                    info_maintenance(urlFileNya);
                }else if (urlFileNya.contains("Wajib")) {
                    info_download(get_pesan);
                }else if (urlFileNya.contains("Sunnah")) {
                    info_download(urlFileNya);
                }
            }else{
                String a = "Sambungan Internet Terputus.\nPastikan Wi-fi atau Data Seluler aktif, lalu coba lagi";
                showAlert(a);
            }

        }

    }

    private void download_informasi_versi(String pesan) {
        AlertDialog.Builder ad = new AlertDialog.Builder(this);
        ad.setTitle("Informasi");
        ad.setMessage(pesan);
        ad.setCancelable(false);
        ad.setIcon(R.drawable.ic_info_outline_24dp);
        ad.setPositiveButton("Download", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                //e-Sppd.v"+kirim_versi+".apk
                //String kirim_versi = cek_versi_apk.getText().toString();
                //String kirim_versi = "1.3.2";
                String Cek = cek_versi_apk;
                try {


                    new Download_Aplikasi().execute(Koneksi.download_apk + "e-Sppd.v"
                           + URLEncoder.encode(Cek, "UTF-8")+".apk");

                } catch (Exception ex) {
                    // TODO Auto-generated catch block
                    //ex.getMessage();
                    ex.printStackTrace();

                }

            }
        });
        ad.setNegativeButton("Nanti ",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();

                    }
                });
        ad.setNeutralButton("Keluar ",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();
                        MainActivityBaru_Petugas.this.finish();
                        finish();

                    }
                });

        ad.show();
    }


    private void info_download(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(message)
                .setTitle("Tersedia Versi Terbaru !!!")
                .setCancelable(false)
                .setIcon(R.drawable.ic_file_download_black)
                .setPositiveButton("Download",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.dismiss();
                                //e-Sppd.v"+kirim_versi+".apk
                                //String kirim_versi = cek_versi_apk.getText().toString();
                                //String kirim_versi = "1.3.2";
                                String Cek = cek_versi_apk;
                                try {
                                      new Download_Aplikasi().execute(Koneksi.download_apk + "e-Sppd.v"
                                            + URLEncoder.encode(Cek, "UTF-8")+".apk");
                                } catch (Exception ex) {
                                    // TODO Auto-generated catch block
                                    //ex.getMessage();
                                    ex.printStackTrace();
                                }


                            }
                        })
                .setNegativeButton("Nanti",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.dismiss();
                                MainActivityBaru_Petugas.this.finish();
                                finish();

                            }
                        })
                .setNeutralButton("Masuk Website",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int id) {
                               // Intent in = null;
                                dialog.dismiss();
                                Intent in = new Intent();
                                in.setAction(Intent.ACTION_VIEW);
                                in.addCategory(Intent.CATEGORY_BROWSABLE);
                                in.setData(Uri.parse(Koneksi.URL_WEBSITE));
                                startActivity(in);

                            }
                        });
        AlertDialog alert = builder.create();
        alert.show();
    }

    class Download_Aplikasi extends AsyncTask<String, String, String>

    {
        @Override
        @SuppressWarnings("deprecation")
        protected void onPreExecute() {
            super.onPreExecute();
            showDialog(progress_DOWNLOAD);

        }

        @Override
        protected String doInBackground(String... f_url) {
            int count;
            String responseString = null; 											// 1
            //String kirim_versi = cek_versi_apk.getText().toString();
            try {

                URL url = new URL(f_url[0]);

                URLConnection connection = url.openConnection();
                connection.connect();

                int lenghOfFile = connection.getContentLength();
                InputStream input = new BufferedInputStream(url.openStream(),
                        8192);

                OutputStream output = new FileOutputStream(
                        "/sdcard/Download/e-Sppd.v"+cek_versi_apk+".apk");
                byte data[] = new byte[1024];
                long total = 0;

                while ((count = input.read(data)) != -1) {
                    total += count;
                    publishProgress("" + (int) ((total * 100) / lenghOfFile));
                    output.write(data, 0, count);
                }
                output.flush();
                output.close();
                input.close();
            } catch (ClientProtocolException e) { 	// 2
                responseString = e.toString();		//
            } catch (IOException e) {				//
                responseString = e.toString();		//3
            }										//
            return responseString;					//4
        }

        @Override
        protected void onProgressUpdate(String... progress) {
            progresdialog.setProgress(Integer.parseInt(progress[0]));
        }

        @Override
        @SuppressWarnings("deprecation")
        protected void onPostExecute(String file_url) {
            dismissDialog(progress_DOWNLOAD);
            Log.e(TAG, "Respon Dari Server ::: " + "Error");

            String pesan1 = "java.net.SocketException: recvfrom failed: ETIMEDOUT (Connection timed out)";
            String pesan2 = "java.net.UnknownHostException: Unable to resolve host";

            if (file_url != null){
                if (file_url.contains(pesan2)){
                    String info_pesan1 = "Download File E-SPPD Terhenti\nTidak Ada Koneksi Internet\n" +
                            "Pastikan Wi-fi atau Data Seluler aktif dan lancar, lalu coba lagi";
                    showAlert(info_pesan1);
                }else if (file_url.contains(pesan1)){
                    String info_pesan1 = "Download File E-SPPD Terhenti\nKoneksi Sambungan Terputus\n" +
                            "Pastikan Wi-fi atau Data Seluler aktif dan lancar, lalu coba lagi";
                    showAlert(info_pesan1);
                }else{
                    refresh();
                }

                //}else if (file_url.equalsIgnoreCase(pesan1)){
                //	String info_pesan2 = "Koneksi Sambungan Terputus\n" +
                //			"Pastikan Wi-fi atau Data Seluler aktif dan lancar, lalu coba lagi";
                //	showAlert(info_pesan2);
            }else{
                String info_pesan3 = "Download Berhasil !!!\nSilahkan Install File E-SPPD V."+cek_versi_apk+" Pada Folder Downloads";
                info_selesai_download(info_pesan3);
            }
            super.onPostExecute(file_url);
        }
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        //String kirim_versi = cek_versi_apk.getText().toString();
        switch (id) {

            case progress_DOWNLOAD:
                progresdialog = new ProgressDialog(this);
                progresdialog.setMessage("Downloading file...\ne-Sppd.v"+cek_versi_apk+".apk");
                progresdialog.setIndeterminate(false);
                progresdialog.setMax(100);
                progresdialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
                progresdialog.setCancelable(false);
                progresdialog.show();
                return progresdialog;
            default:

                return null;
        }
    }
    private void info_maintenance(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(message)
                .setTitle("Informasi")
                .setCancelable(false)
                .setIcon(R.drawable.ic_info_outline_24dp)
                .setPositiveButton("Ok",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.dismiss();
                                MainActivityBaru_Petugas.this.finish();
                                finish();

                            }
                        });
        AlertDialog alert = builder.create();
        alert.show();
    }
    private void info_selesai_download(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(message)
                .setTitle("Informasi")
                .setCancelable(false)
                .setIcon(R.drawable.ic_info_outline_24dp)
                .setPositiveButton("Ok",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.dismiss();
                                MainActivityBaru_Petugas.this.finish();
                                finish();
                            }
                        });
        AlertDialog alert = builder.create();
        alert.show();
    }

    private void info_tak_ada_koneksi(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(message)
                .setTitle("Peringatan")
                .setCancelable(false)
                .setIcon(R.drawable.ic_warning_black)
                .setPositiveButton("Ok",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.dismiss();
                                refresh();

                            }
                        });
        AlertDialog alert = builder.create();
        alert.show();
    }
    private void showAlert(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(message)
                .setTitle("Peringatan")
                .setCancelable(false)
                .setIcon(R.drawable.ic_warning_black)
                .setPositiveButton("Coba Lagi",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.dismiss();
                                finish();
                                startActivity(getIntent());
                            }
                        })
                .setNeutralButton("Keluar",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.dismiss();
                                MainActivityBaru_Petugas.this.finish();
                                finish();
                            }
                        });
        AlertDialog alert = builder.create();
        alert.show();
    }
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        // Untuk memanggil layout dari menu yang dipilih
        if (id == R.id.menu1) {
            finish();
            startActivity(getIntent());
            Toast.makeText(MainActivityBaru_Petugas.this, "Selamat Datang\n"+nama_pegawai,
                           Toast.LENGTH_LONG).show();

         //   new Activity_Gambar().onDestroyView();
        //    fragment = new Activity_Gambar();
         //   callFragment(fragment);
        } else if (id == R.id.menu2) {
            Intent in = null;

            in = new Intent(MainActivityBaru_Petugas.this, Daftar_Laporan_Per_Petugas.class);

            Bundle bun = new Bundle();
            bun.putString("transfer_nip", nip);
            bun.putString("versi", cek_versi_apk);
            in.putExtras(bun);
            startActivity(in);
        } else if (id == R.id.menu3) {
            Intent in = null;

            in = new Intent(MainActivityBaru_Petugas.this, History.class);

            Bundle bun = new Bundle();
            bun.putString("transfer_nip", nip);
            bun.putString("versi", cek_versi_apk);
            in.putExtras(bun);
            startActivity(in);

        } else if (id == R.id.menu4) {
            Intent in = null;

            in = new Intent(MainActivityBaru_Petugas.this, Profil.class);

            Bundle bun = new Bundle();
            bun.putString("transfer_nip", nip);
            bun.putString("versi", cek_versi_apk);
            bun.putString("transfer_nama_pegawai", nama_pegawai);
            bun.putString("transfer_jabatan", jabatan);
            bun.putString("transfer_golongan", golongan);
            bun.putString("transfer_password", password);
            in.putExtras(bun);
            startActivity(in);

        } else if (id == R.id.menu5) {

            //String nip3 = ambil_nip.getText().toString();
           // String versi = cek_versi_apk.getText().toString();
          //  MainActivityBaru_Petugas.this.finish();
           // finish();
            Intent in = null;

            in = new Intent(MainActivityBaru_Petugas.this, Tentang_Aplikasi.class);

            Bundle bun = new Bundle();
            bun.putString("transfer_nip", nip);
            bun.putString("versi", cek_versi_apk);
            in.putExtras(bun);
            startActivity(in);
        } else if (id == R.id.menu6) {
            infodialogback();
        }

        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    // untuk mengganti isi kontainer menu yang dipiih
    private void callFragment(Fragment fragment) {
        fragmentManager = getFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.frame_container, fragment)
                .commit();
    }

    @Override
    public void onBackPressed() {
        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            if (doubleBackToExitPressedOnce) {
                super.onBackPressed();
                return;
            }
            this.doubleBackToExitPressedOnce = true;
            Toast.makeText(this, "Klik Tombol Kembali Dua Kali (2x) Untuk Keluar Dari Aplikasi E-SPPD", Toast.LENGTH_SHORT).show();
            new Handler().postDelayed(new Runnable() {

                @Override
                public void run() {
                    doubleBackToExitPressedOnce = false;

                }
            }, 2000);
        }

    }
    private void infodialogback() {
        AlertDialog.Builder ad = new AlertDialog.Builder(this);
        ad.setTitle("Informasi");
        ad.setIcon(R.drawable.ic_lock_black);
        ad.setMessage("Anda Akan Keluar Dari Session Aplikasi E-SPPD dan Kembali ke Menu Login ?");
        ad.setPositiveButton("Keluar", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                SharedPreferences.Editor editor = sharedpreferences.edit();
                editor.putBoolean(Login_Activity.session_status_level2, false);
                editor.putString(TAG_NIP, null);
                editor.putString(TAG_NAMA_PEGAWAI, null);
                editor.putString(TAG_JABATAN, null);
                editor.putString(TAG_GOLONGAN, null);
                editor.putString(TAG_PASSWORD, null);
                editor.putString(versi, null);
                editor.commit();
                Intent intent = new Intent(MainActivityBaru_Petugas.this, Login_Activity.class);
                finish();
                startActivity(intent);
            }
        });

        ad.setNeutralButton("Batal", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        ad.show();
    }

    private Runnable runnable = new Runnable() {

        @SuppressLint("SimpleDateFormat")
        @Override
        public void run() {
            // TODO Auto-generated method stub
            Calendar c1 = Calendar.getInstance();

            SimpleDateFormat tgl_skrng = new SimpleDateFormat("d MMM yyyy");
            SimpleDateFormat jam_skrng = new SimpleDateFormat("HH:mm:s");
            // SimpleDateFormat sdf1 = new SimpleDateFormat("d/M/yyyy h:m:s a");
            String strdate_tgl = tgl_skrng.format(c1.getTime());
            String strdate_jam = jam_skrng.format(c1.getTime());

            tgl_utama.setText(strdate_tgl);
            jam_utama.setText(strdate_jam);

            handler.postDelayed(this, 1000);
        }

    };
    public void refresh(View view) {
        finish();
        startActivity(getIntent());
    }
    public void menu(View view) {
        drawer.openDrawer(GravityCompat.START);
    }
    public void refresh() {
        finish();
        startActivity(getIntent());
    }
}
