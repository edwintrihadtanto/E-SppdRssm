package com.e_sppd_rssm;

import java.util.ArrayList;
import java.util.List;

import koneksi.Daftar_String;
import android.annotation.SuppressLint;
import android.content.Context;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.e_sppd.rssm.R;

import static com.e_sppd.rssm.R.color.*;

@SuppressLint("DefaultLocale")
public class List_Daftar_SPT_per_nip extends BaseAdapter implements Filterable {

	private Context context;
	private List<Daftar_String> list, filterd;
	private CheckBox centangdaftar;
	public List_Daftar_SPT_per_nip(Context context, List<Daftar_String> list) {
		this.context = context;
		this.list = list;
		this.filterd = this.list;
	}

	@Override
	public int getCount() {

		return filterd.size();
	}

	@Override
	public Object getItem(int position) {

		return filterd.get(position);
	}

	@Override
	public long getItemId(int position) {

		return position;
	}

	@SuppressLint({"InflateParams", "ResourceAsColor"})
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		if (convertView == null) {
			LayoutInflater inflater = LayoutInflater.from(this.context);
			convertView = inflater.inflate(R.layout.row_list_detail_datasppd,
					null);

		}
		
		Daftar_String mhs = filterd.get(position);
		// RelativeLayout pengatur_layout =
		// (RelativeLayout)convertView.findViewById(R.id.pengatur_layout);

		ImageView status_posting_merah = (ImageView) convertView
				.findViewById(R.id.status_posting);
		ImageView status_posting_hijau = (ImageView) convertView
				.findViewById(R.id.status_posting2);

		ImageView status_posting_merah1 = (ImageView) convertView
				.findViewById(R.id.status_posting1);
		ImageView status_posting_hijau1 = (ImageView) convertView
				.findViewById(R.id.status_posting12);

		ImageView status_posting_merah2 = (ImageView) convertView
				.findViewById(R.id.status_posting3);
		ImageView status_posting_hijau2 = (ImageView) convertView
				.findViewById(R.id.status_posting31);

		TextView menampilkan_nomor_spt = (TextView) convertView
				.findViewById(R.id.menampilkan_nomor_spt);
		menampilkan_nomor_spt.setText(mhs.getnomor_SPT());

		TextView menampilkan_nomor_sppd = (TextView) convertView
				.findViewById(R.id.menampilkan_nomor_sppd);
		menampilkan_nomor_sppd.setText(mhs.getnomor_SPPD());

		TextView text_tgl_keberangkatan = (TextView) convertView
				.findViewById(R.id.text_tgl_keberangkatan);
		text_tgl_keberangkatan.setText(mhs.gettgl_brngkt());

		TextView text_tgl_tiba = (TextView) convertView
				.findViewById(R.id.text_tgl_tiba);
		text_tgl_tiba.setText(mhs.gettgl_kembali());

		TextView text_lama_perjalanan = (TextView) convertView
				.findViewById(R.id.text_lama_perjalanan);
		text_lama_perjalanan.setText(mhs.getlama_perj() + " Hari");

		TextView status_lap_perj = (TextView) convertView
				.findViewById(R.id.status_lap_perj);
		status_lap_perj.setText(mhs.getstatus_laporan_petugas());

		TextView status_rincian = (TextView) convertView
				.findViewById(R.id.status_rincian);
		status_rincian.setText(mhs.getstatus_rincian());

		TextView status_riil = (TextView) convertView
				.findViewById(R.id.status_riil);

		TextView text_sts_post = (TextView) convertView.findViewById(R.id.text_sts_post);
		text_sts_post.setText(mhs.getsts_postingan());
		ImageView sts_post1 = (ImageView) convertView
				.findViewById(R.id.sts_post1);


		if (text_sts_post.getText().toString().contains("1")){
			text_sts_post.setText("SUDAH POSTING");
			sts_post1.setBackgroundResource(R.drawable.hijau);
			text_sts_post.setVisibility(View.VISIBLE);
			sts_post1.setVisibility(View.VISIBLE);
		}else{
			text_sts_post.setText("BELUM POSTING");
			sts_post1.setBackgroundResource(R.drawable.merah);
			text_sts_post.setVisibility(View.VISIBLE);
			sts_post1.setVisibility(View.VISIBLE);
		}
		
		status_riil.setVisibility(View.VISIBLE);
		status_riil.setText(mhs.getstatus_riil());

		String cek_status_lap 		= status_lap_perj.getText().toString().trim();
		String cek_status_rincian 	= status_rincian.getText().toString().trim();
		String cek_status_riil 		= status_riil.getText().toString().trim();

		TextView status_lap_perj2 = (TextView) convertView.findViewById(R.id.status_lap_perj2);
		TextView status_rincian2 = (TextView) convertView.findViewById(R.id.status_rincian2);
		TextView status_riil2 = (TextView) convertView.findViewById(R.id.status_riil2);
		View a = (View) convertView.findViewById(R.id.ko);
		View a2 = (View) convertView.findViewById(R.id.ko2);

		if (cek_status_lap.contains("SUDAH")) {
			status_lap_perj.setVisibility(View.GONE);
			status_posting_hijau.setVisibility(View.VISIBLE);
			status_lap_perj2.setVisibility(View.VISIBLE);
		} else {
			status_posting_merah.setVisibility(View.VISIBLE);
		}

		if (cek_status_rincian.contains("SUDAH")) {
			status_rincian2.setVisibility(View.GONE);
			status_posting_hijau1.setVisibility(View.VISIBLE);
			status_rincian2.setVisibility(View.VISIBLE);
		} else {
			status_posting_merah1.setVisibility(View.VISIBLE);
		}

		if (cek_status_riil.contains("SUDAH")) {
			status_riil.setVisibility(View.GONE);
			status_posting_hijau2.setVisibility(View.VISIBLE);
			status_riil2.setVisibility(View.VISIBLE);
			int b = status_riil.getVisibility();
			if (b == View.GONE){
				a.setVisibility(View.GONE);
				a2.setVisibility(View.VISIBLE);
			}else{
				a2.setVisibility(View.GONE);
			}
		} else {
			status_posting_merah2.setVisibility(View.VISIBLE);

		}

		centangdaftar = (CheckBox) convertView.findViewById(R.id.centangdaftar);
		centangdaftar.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if (!isChecked) {
					// show password
					centangdaftar.setChecked(false);
					//edit_pass.setTransformationMethod(PasswordTransformationMethod.getInstance());
				} else {
					centangdaftar.setChecked(true);
					// hide password
					//edit_pass.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
				}
			}
		});

		return convertView;
	}

	@Override
	public Filter getFilter() {

		ListDataPegawai_Filter filter = new ListDataPegawai_Filter();
		return filter;
	}

	/** Class filter untuk melakukan filter (pencarian) */

	private class ListDataPegawai_Filter extends Filter {
		@Override
		protected FilterResults performFiltering(CharSequence constraint) {
			List<Daftar_String> filteredData = new ArrayList<Daftar_String>();
			FilterResults result = new FilterResults();
			String filterString = constraint.toString().toLowerCase();

			for (Daftar_String mhs : list) {

				if ((mhs.gettgl_aktivitas().toString().contains(filterString))) {
					filteredData.add(mhs);
				}
			}
			result.count = filteredData.size();
			result.values = filteredData;
			return result;
		}

		@SuppressWarnings("unchecked")
		@Override
		protected void publishResults(CharSequence constraint,
				FilterResults results) {

			filterd = (List<Daftar_String>) results.values;
			notifyDataSetChanged();
		}

	}

}
