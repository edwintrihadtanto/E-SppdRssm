package com.e_sppd_rssm;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import bantuan_tutorial.Tutorial;

import com.e_sppd.rssm.R;

import static com.e_sppd.rssm.R.animator.welcome_anim_satu;
import static com.e_sppd.rssm.R.animator.welcome_anim_dua;

public class Splash_Screen extends Activity {
	ImageView imageview, img_welcome23;
	Animation anim_satu, anim_dua;

	@SuppressLint("ResourceType")
    @Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.splash_welcome);
		imageview = (ImageView) findViewById(R.id.img_welcome);
		img_welcome23 = (ImageView) findViewById(R.id.img_welcome23);

		anim_satu = AnimationUtils.loadAnimation(getApplicationContext(),
				welcome_anim_satu);
		anim_dua = AnimationUtils.loadAnimation(getApplicationContext(),
				welcome_anim_dua);

		imageview.setAnimation(anim_satu);
		anim_satu.setAnimationListener(new Animation.AnimationListener() {

			@Override
			public void onAnimationStart(Animation animation) {

			}

			@Override
			public void onAnimationRepeat(Animation animation) {

			}

			@Override
			public void onAnimationEnd(Animation animation) {
				finish();
				Intent i = null;
				i = new Intent(Splash_Screen.this, Tutorial.class);

				startActivity(i);
			}
		});

		img_welcome23.setAnimation(anim_dua);
		anim_dua.setAnimationListener(new Animation.AnimationListener() {

			@Override
			public void onAnimationStart(Animation animation) {

			}

			@Override
			public void onAnimationRepeat(Animation animation) {

			}

			@Override
			public void onAnimationEnd(Animation animation) {
				finish();
			}
		});

	}

}
