package com.e_sppd_rssm;

import java.io.BufferedInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import br.com.bloder.magic.view.MagicButton;
import koneksi.Daftar_String;
import koneksi.Java_Connection;
import koneksi.Koneksi;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.e_sppd.rssm.R;

public class Daftar_Laporan_Per_Petugas extends Activity {
	private static final String TAG = "DaftarPetugas";
	private ListView listView, list_notif;
	private Koneksi Koneksi_Server;
	private List<Daftar_String> list, listpost;
	private List_Daftar_SPT_per_nip adapter;
	private List_Informasi informasi;
	private TextView nip_lokal;
	private ProgressDialog loading;
	private ImageView ImageView_Help;
	private Daftar_String selectedList;
//	JSONParser classJsonParser = new JSONParser();

	private static final int progress_bar_type_spt 	= 0; 
	private static final int progress_bar_type_sppd = 1;

	RelativeLayout laylistrecent;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.list_tampil_detail_datasppd);
		nip_lokal = (TextView) findViewById(R.id.nip_lokal);

		laylistrecent = (RelativeLayout) findViewById(R.id.laylistrecent);
		Bundle b = getIntent().getExtras();
		String transfer_nip = b.getString("transfer_nip");
		nip_lokal.setText(transfer_nip);

		Koneksi_Server = new Koneksi();
		//---------------
		listView 	= (ListView) findViewById(R.id.list_daftar_sppd);
		list 		= new ArrayList<Daftar_String>();
		new MainActivityAsync().execute();
		
		//---------------
		list_notif 	= (ListView) findViewById(R.id.list_notif);
		listpost 	= new ArrayList<Daftar_String>();		
		
		ImageView_Help = (ImageView) findViewById(R.id.ImageView_Help);	
		ImageView_Help.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
			//String pesan = "Sipp Mantap";
			//showAlert(pesan);
				Intent i = null;
				i = new Intent(Daftar_Laporan_Per_Petugas.this,
						Tampil_Bantuan.class);
				startActivity(i);				
			}
		});
		String pesan = "Untuk Pembuatan\n" +
				"- Laporan Perjalanan Dinas\n" +
				"- Perincian Biaya dan\n" +
				"- Pengeluaran Riil\n" +
				"-+++- Pilih (Tekan Tahan) Daftar SPT dan SPPD Yang Akan Dikerjakan -+++-";
		info_pesan(pesan);
	}

	private class MainActivityAsync extends AsyncTask<String, Void, String> {

		@Override
		protected void onPreExecute() {
			loading = new ProgressDialog(Daftar_Laporan_Per_Petugas.this);
			loading.setMessage("Loading . . .");
			loading.setIndeterminate(false);
			loading.setCancelable(false);
			loading.show();
		}

		@Override
		protected String doInBackground(String... params) {

			/** Mengirimkan request ke server dan memproses JSON response */
			String nip_pegawai = nip_lokal.getText().toString().trim();

			String Cek = String.valueOf(nip_pegawai);
			String url, url2;
			String responseString = null; 		
			// Super PENTINGGGGGGGGGGGGGGGGGGGGGG PUOOLLLLLLLLLL
			// Barokallah Alhamdulilah KETEMU CARANE MENGATASI
			// DATA NIP YANG BERSIFAT VARCHAR DENGAN SPASI BANYAK
			try {

				url = Koneksi_Server
						.sendGetRequest(Koneksi.tampil_daftar_sppd_per_nip
								+ "?nip_pegawai="
								+ URLEncoder.encode(Cek, "UTF-8"));
				url2 = Koneksi_Server
						.sendGetRequest(Koneksi.tampil_daftar_sppd_per_nip_POSTING
								+ "?nip_pegawai="
								+ URLEncoder.encode(Cek, "UTF-8"));
				
				listpost 	= proses_pengambilan_data_jmlh_postingan(url2);
				
				list 		= proses_pengambilan_data(url);
			
			} catch (IOException e) {
				// TODO Auto-generated catch block
				responseString = e.toString();								
			}catch (Exception e) {
				responseString = e.toString();	
			}

			return responseString;
		}

		
		@Override
		protected void onPostExecute(String result) {
			loading.dismiss();
			Log.e(TAG, "Respon Dari Server" + result);
			String pesan = "java.lang.NullPointerException";
			if (result != null) {
				if (result.contains(pesan)){
					String info_pesan1 = "Gagal Sinkronisasi Data ...";	
					showAlert(info_pesan1);	
				}				
			}else{				
				menampilkan_nama_pegawai();
				tampil_jml_post();
				
			}
					
			super.onPostExecute(result);		
		}

	}

	
	public void refresh(View view) {
		finish();
		startActivity(getIntent());
	}

	private List<Daftar_String> proses_pengambilan_data(String response) {
		List<Daftar_String> list_Daftar_String = new ArrayList<Daftar_String>();
		try {
			JSONObject jsonObj = new JSONObject(response);
			JSONArray jsonArray = jsonObj.getJSONArray("tampil_daftar_sppd");
			Log.d(TAG, "data lengt: " + jsonArray.length());
			Daftar_String mhs = null;
			for (int i = 0; i < jsonArray.length(); i++) {
				JSONObject obj = jsonArray.getJSONObject(i);
				mhs = new Daftar_String();
				mhs.setid_sppd(obj.getString("id_sppd"));
				mhs.setid_spt(obj.getString("id_spt"));
				mhs.setnomor_SPT(obj.getString("nomor_spt"));
				mhs.setnomor_SPPD(obj.getString("nomor_surat_sppd"));
				mhs.setnip(obj.getString("nip"));
				mhs.setnama_pegawai(obj.getString("nama_pegawai"));
				mhs.setjabatan(obj.getString("jabatan"));
				mhs.setgolongan(obj.getString("golongan"));
				mhs.setbiaya_perj(obj.getString("biaya_perj"));
				mhs.setmaksud_perj(obj.getString("maksud_perj"));
				mhs.setalat_angkutan(obj.getString("alat_angkutan"));
				mhs.settempat_brngkt(obj.getString("tempat_brngkt"));
				mhs.settempat_tujuan(obj.getString("tempat_tujuan"));
				mhs.setlama_perj(obj.getString("lama_perj"));
				mhs.settgl_brngkt(obj.getString("tgl_brngkt"));
				mhs.settgl_kembali(obj.getString("tgl_kembali"));
				mhs.settambh_pengikut1(obj.getString("tambh_pengikut1"));
				mhs.settambh_pengikut2(obj.getString("tambh_pengikut2"));
				mhs.settambh_pengikut3(obj.getString("tambh_pengikut3"));
				mhs.settambh_pengikut4(obj.getString("tambh_pengikut4"));
				mhs.settambh_pengikut5(obj.getString("tambh_pengikut5"));
				mhs.settgl_aktivitas(obj.getString("tanggal_aktivitas"));
				mhs.setjam_aktivitas(obj.getString("waktu_aktivitas"));
				mhs.setsurat_masuk_dari(obj.getString("surat_masuk_dari"));
				mhs.settgl_surat_spt_masuk(obj.getString("tgl_surat_masuk"));
				mhs.setakun_anggaran(obj.getString("akun_pembebanan_anggaran"));
				mhs.setstatus_laporan_petugas(obj
						.getString("status_laporan_petugas"));
				mhs.setstatus_riil(obj.getString("status_riil"));
				mhs.setstatus_rincian(obj.getString("status_rincian_biaya"));
				mhs.setsts_postingan(obj.getString("status_post"));
				//KHUSUS PENGAMBILAN LAPORAN 
				mhs.setnip_pembuatlaporanperj(obj.getString("nip_pembuatlaporanperj"));
				mhs.setnomor_spt_laporanperj(obj.getString("nomor_spt_laporanperj"));
				mhs.sethasil_pertemuan(obj.getString("hasil_pertemuan"));
				mhs.setmasalah(obj.getString("masalah"));
				mhs.setsaran(obj.getString("saran"));
				mhs.setlain_lain(obj.getString("lain_lain"));
				mhs.settgl_pembuatan_laporan(obj.getString("tgl_pembuatan_laporan"));

				list_Daftar_String.add(mhs);
			}
		} catch (JSONException e) {

			if (e.getMessage() != null) {
				Log.d(TAG, e.getMessage());
			} else {
				Toast.makeText(Daftar_Laporan_Per_Petugas.this,
						"Gagal Mengambil Data", Toast.LENGTH_LONG).show();
			}

		}
		return list_Daftar_String;
	}

	private List<Daftar_String> proses_pengambilan_data_jmlh_postingan(String response) {
		List<Daftar_String> list_Daftar_String = new ArrayList<Daftar_String>();
		try {
			JSONObject jsonObj = new JSONObject(response);
			JSONArray jsonArray = jsonObj.getJSONArray("tampil_jmlh_blmpostingan");
			Log.d(TAG, "data lengt: " + jsonArray.length());
			Daftar_String jml = null;
			for (int i = 0; i < jsonArray.length(); i++) {
				JSONObject obj = jsonArray.getJSONObject(i);
				jml = new Daftar_String();				
				jml.setjml_stspost(obj.getString("jml_stspost")); //AMBIL POSTINGAN JUMLAHNYA
				jml.setjml_nomor_surat_sppd(obj.getString("jml_nomor_surat_sppd")); 
				jml.setnote(obj.getString("note")); 
				list_Daftar_String.add(jml);
				
			}
		} catch (JSONException e) {

			if (e.getMessage() != null) {
				Log.d(TAG, e.getMessage());
			} else {
				Toast.makeText(Daftar_Laporan_Per_Petugas.this,
						"Gagal Mengambil Data", Toast.LENGTH_LONG).show();
			}

		}
		return list_Daftar_String;
	}
	
	private void tampil_jml_post() {
		if (!terkoneksi(Daftar_Laporan_Per_Petugas.this)) {
			String pesan = "Tidak ada sambungan Internet.\nPastikan Wi-fi atau Data Seluler aktif, lalu coba lagi";
			showAlert(pesan);
			return;
		} else {			
			informasi = new List_Informasi(getApplicationContext(), listpost);		
			list_notif.setAdapter(informasi);			
		}
	}
	
	private void menampilkan_nama_pegawai() {
		if (!terkoneksi(Daftar_Laporan_Per_Petugas.this)) {
			String pesan = "Tidak ada sambungan Internet.\nPastikan Wi-fi atau Data Seluler aktif, lalu coba lagi";
			showAlert(pesan);
			return;
		} else {
			
			adapter = new List_Daftar_SPT_per_nip(getApplicationContext(), list);						
			listView.setAdapter(adapter);
			listView.setOnItemLongClickListener(new OnItemLongClickListener() {

				@Override
				public boolean onItemLongClick(AdapterView<?> parent,
						View view, int pos, long id) {
					// TODO Auto-generated method stub
					selectedList = (Daftar_String) adapter.getItem(pos);
					tampil_pilihan_menu();
					return true;
				}
			});
		}
	}

	private boolean terkoneksi(Context mContext) {
		ConnectivityManager cm = (ConnectivityManager) mContext
				.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo netInfo = cm.getActiveNetworkInfo();
		if (netInfo != null && netInfo.isConnectedOrConnecting()) {
			// Toast.makeText(getApplication(), "Koneksi Internet Tersedia",
			// Toast.LENGTH_SHORT).show();
			return true;
		}
		return false;

	}

	private void tampil_pilihan_menu() {
		final Dialog dialog2 = new Dialog(this);
		dialog2.requestWindowFeature(Window.FEATURE_NO_TITLE);
		dialog2.setContentView(R.layout.dialog_pilihan_daftar_petugas);
		//String cek_nip_pembuat_lap 						= selectedList.getnip_pembuatlaporanperj();

		CardView btn_gotoinput_lap_perj_dinas 				= (CardView) dialog2.findViewById(R.id.btn_gotoinput_lap_perj_dinas);
		CardView btn_gotocek_spt 							= (CardView) dialog2.findViewById(R.id.btn_gotocek_spt);
		CardView btn_gotocek_sppd 							= (CardView) dialog2.findViewById(R.id.btn_gotocek_sppd);
		CardView btn_gotoinputdaftar_pengeluaran_rincian 	= (CardView) dialog2.findViewById(R.id.btn_gotoinputdaftar_pengeluaran_rincian);
		CardView btn_gotoinputdaftar_pengeluaran_riil 		= (CardView) dialog2.findViewById(R.id.btn_gotoinputdaftar_pengeluaran_riil);
		CardView btn_posting 								= (CardView) dialog2.findViewById(R.id.btn_posting);

		dialog2.show();

		btn_gotoinput_lap_perj_dinas.setOnClickListener(new View.OnClickListener() {
				//.setMagicButtonClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						String cek_laporanperjalanan 	= selectedList.getstatus_laporan_petugas();
						String cek_nip_pembuat_lap 		= selectedList.getnip_pembuatlaporanperj();
						String cek_nip_login			= selectedList.getnip();
						
						if (cek_laporanperjalanan.isEmpty()||cek_laporanperjalanan.contains("null")) {	
							//dialog2.dismiss();
							String pesan = "Telah Terjadi Kesalahan Status Laporan Perjalanan Dinas Anda\nSegera Hubungi Admin !!!";
							showAlert_Khusus_Lap(pesan);
						}else if (cek_laporanperjalanan.contains("SUDAH")) {					
							
							if (cek_nip_pembuat_lap.contains(cek_nip_login)){
								dialog2.dismiss();
								String pesan2 = "Anda Sudah Membuat Laporan Perjalanan Dinas\nEdit Data Laporan Perjalanan Dinas ?";
								ALert_Edit_Laporan_Perjalanan_Dinas(pesan2);
							}else{
								dialog2.dismiss();
								String pesan = "Anda Sudah Membuat Laporan Perjalanan Dinas\n"+"NIP/NPK Pembuat Laporan : "+cek_nip_pembuat_lap;
								showAlert_Khusus_Lap(pesan);
							}
						}else{
						dialog2.dismiss();
						Daftar_Laporan_Per_Petugas.this.finish();
						finish();
						Intent i = null;
						i = new Intent(Daftar_Laporan_Per_Petugas.this,
								Pembuatan_Lap_Setelah_Perj_Dinas.class);
						i.putExtra("id_spt", selectedList.getid_spt());
						i.putExtra("nomor_spt", selectedList.getnomor_SPT());
						i.putExtra("nomor_surat_sppd", selectedList
								.getnomor_SPPD());
						i.putExtra("nip", selectedList.getnip());
						i.putExtra("nama_pegawai", selectedList.getnama_pegawai());
						i.putExtra("jabatan", selectedList.getjabatan());
						i.putExtra("golongan", selectedList.getgolongan());
						i.putExtra("biaya_perj", selectedList.getbiaya_perj());
						i.putExtra("maksud_perj", selectedList.getmaksud_perj());
						i.putExtra("alat_angkutan",
								selectedList.getalat_angkutan());
						i.putExtra("tempat_brngkt",
								selectedList.gettempat_brngkt());
						i.putExtra("tempat_tujuan",
								selectedList.gettempat_tujuan());
						i.putExtra("lama_perj", selectedList.getlama_perj());
						i.putExtra("tgl_brngkt", selectedList.gettgl_brngkt());
						i.putExtra("tgl_kembali", selectedList.gettgl_kembali());
						i.putExtra("tambh_pengikut1",
								selectedList.gettambh_pengikut1());
						i.putExtra("tambh_pengikut2",
								selectedList.gettambh_pengikut2());
						i.putExtra("tambh_pengikut3",
								selectedList.gettambh_pengikut3());
						i.putExtra("tambh_pengikut4",
								selectedList.gettambh_pengikut4());
						i.putExtra("tambh_pengikut5",
								selectedList.gettambh_pengikut5());
						i.putExtra("tanggal_aktivitas",
								selectedList.gettgl_aktivitas());
						i.putExtra("waktu_aktivitas",
								selectedList.getjam_aktivitas());
						i.putExtra("akun_pembebanan_anggaran",
								selectedList.getakun_anggaran());
						i.putExtra("surat_masuk_dari",
								selectedList.getsurat_masuk_dari());
						i.putExtra("tgl_surat_masuk",
								selectedList.gettgl_surat_spt_masuk());
						i.putExtra("status_laporan_petugas",
								selectedList.getstatus_laporan_petugas());
						//------------------------
						i.putExtra("nip_pembuatlaporanperj",
								selectedList.getnip_pembuatlaporanperj());
						i.putExtra("nomor_spt_laporanperj",
								selectedList.getnomor_spt_laporanperj());
						i.putExtra("hasil_pertemuan",
								selectedList.gethasil_pertemuan());
						i.putExtra("masalah",
								selectedList.getmasalah());
						i.putExtra("saran",
								selectedList.getsaran());
						i.putExtra("lain_lain",
								selectedList.getlain_lain());
						i.putExtra("tgl_pembuatan_laporan",
								selectedList.gettgl_pembuatan_laporan());
						
						
						startActivity(i);
					
						}
						
					}
				});

		btn_gotocek_spt.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				dialog2.dismiss();
				if (!terkoneksi(Daftar_Laporan_Per_Petugas.this)) {
					String pesan = "Tidak ada sambungan Internet.\nPastikan Wi-fi atau Data Seluler aktif, lalu coba lagi";
					showAlert(pesan);
					return;
				} else {
					String id_spt = selectedList.getid_spt();
					String Cek = String.valueOf(id_spt);
					try {
	
						new DownloadFile_SPT().execute(Koneksi.download_spt + "?id_spt="
								+ URLEncoder.encode(Cek, "UTF-8"));
	
					} catch (UnsupportedEncodingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		});

		btn_gotocek_sppd.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				dialog2.dismiss();
				if (!terkoneksi(Daftar_Laporan_Per_Petugas.this)) {
					String pesan = "Tidak ada sambungan Internet.\nPastikan Wi-fi atau Data Seluler aktif, lalu coba lagi";
					showAlert(pesan);
					return;
				} else {
					String id_sppd = selectedList.getid_sppd();
					String Cek = String.valueOf(id_sppd);
	
					try {
	
						new DownloadFile_SPPD().execute(Koneksi.download_sppd + "?id_sppd="
								+ URLEncoder.encode(Cek, "UTF-8"));
	
					} catch (UnsupportedEncodingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		});

		btn_gotoinputdaftar_pengeluaran_rincian
				.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						String cek_status_rincian = selectedList.getstatus_rincian();
						String cek_laporanperjalanan = selectedList.getstatus_laporan_petugas();
						if (cek_laporanperjalanan.isEmpty()||cek_laporanperjalanan.contains("null")) {	
							//dialog2.dismiss();
							String pesan = "Telah Terjadi Kesalahan Status Laporan Perjalanan Dinas Anda\nSegera Hubungi Admin !!!";
							showAlert_Khusus_Lap(pesan);
						}else if (cek_laporanperjalanan.contains("BELUM")) {					
							String pesan = "Silahkan Anda Buat Laporan Perjalanan Dinas Terlebih Dahulu";
							showAlert_Khusus_Lap(pesan);
						}else if (cek_status_rincian.isEmpty()||cek_status_rincian.contains("null")) {	
								//dialog2.dismiss();
							String pesan = "Telah Terjadi Kesalahan Status Perincian Biaya Anda\nSegera Hubungi Admin !!!";
							showAlert_Khusus_Lap(pesan);
							
						}else if (cek_status_rincian.contains("BELUM")) {
							dialog2.dismiss();
							finish();
							Daftar_Laporan_Per_Petugas.this.finish();
						
						Intent i = null;
						i = new Intent(Daftar_Laporan_Per_Petugas.this,
								Laporan_Rincian_Biaya_Perj_Dinas.class);
						i.putExtra("id_spt", selectedList.getid_spt());
						i.putExtra("nomor_spt", selectedList.getnomor_SPT());
						i.putExtra("nomor_surat_sppd", selectedList.getnomor_SPPD());
						i.putExtra("nip", selectedList.getnip());
						i.putExtra("nama_pegawai", selectedList.getnama_pegawai());
						i.putExtra("jabatan", selectedList.getjabatan());
						i.putExtra("golongan", selectedList.getgolongan());
						i.putExtra("biaya_perj", selectedList.getbiaya_perj());
						i.putExtra("maksud_perj", selectedList.getmaksud_perj());
						i.putExtra("alat_angkutan",
								selectedList.getalat_angkutan());
						i.putExtra("tempat_brngkt",
								selectedList.gettempat_brngkt());
						i.putExtra("tempat_tujuan",
								selectedList.gettempat_tujuan());
						i.putExtra("lama_perj", selectedList.getlama_perj());
						i.putExtra("tgl_brngkt", selectedList.gettgl_brngkt());
						i.putExtra("tgl_kembali", selectedList.gettgl_kembali());
						i.putExtra("tambh_pengikut1",
								selectedList.gettambh_pengikut1());
						i.putExtra("tambh_pengikut2",
								selectedList.gettambh_pengikut2());
						i.putExtra("tambh_pengikut3",
								selectedList.gettambh_pengikut3());
						i.putExtra("tambh_pengikut4",
								selectedList.gettambh_pengikut4());
						i.putExtra("tambh_pengikut5",
								selectedList.gettambh_pengikut5());
						i.putExtra("tanggal_aktivitas",
								selectedList.gettgl_aktivitas());
						i.putExtra("waktu_aktivitas",
								selectedList.getjam_aktivitas());
						i.putExtra("akun_pembebanan_anggaran",
								selectedList.getakun_anggaran());
						i.putExtra("surat_masuk_dari",
								selectedList.getsurat_masuk_dari());
						i.putExtra("tgl_surat_masuk",
								selectedList.gettgl_surat_spt_masuk());
						i.putExtra("status_laporan_petugas",
								selectedList.getstatus_laporan_petugas());
						i.putExtra("status_rincian_biaya", selectedList.getstatus_rincian());
						i.putExtra("status_riil", selectedList.getstatus_riil());
						startActivity(i);
						
						}else{
							dialog2.dismiss();
							String pesan = "Anda Sudah Membuat Perincian Biaya\nEdit Laporan Perincian Biaya ?";
							ALert_Edit_Laporan_Rincian(pesan);
						}

					}
				});

		btn_gotoinputdaftar_pengeluaran_riil.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						String cek_laporanperjalanan = selectedList.getstatus_laporan_petugas();
						String cek_riil = selectedList.getstatus_riil();
						if (cek_laporanperjalanan.isEmpty()||cek_laporanperjalanan.contains("null")) {	
							//dialog2.dismiss();
							String pesan = "Telah Terjadi Kesalahan Status Laporan Perjalanan Dinas Anda\nSegera Hubungi Admin !!!";
							showAlert_Khusus_Lap(pesan);
						}else if (cek_laporanperjalanan.contains("BELUM")) {					
							String pesan = "Silahkan Anda Buat Laporan Perjalanan Dinas Terlebih Dahulu";
							showAlert_Khusus_Lap(pesan);
						}else if (cek_riil.isEmpty()||cek_riil.contains("null")) {	
							//dialog2.dismiss();
							String pesan = "Telah Terjadi Kesalahan Status Perincian Biaya Riil Anda\nSegera Hubungi Admin !!!";
							showAlert_Khusus_Lap(pesan);
						}else if (cek_riil.contains("SUDAH")) {
							dialog2.dismiss();
							String pesan = "Anda Sudah Membuat Laporan Pengeluaran Riil\nEdit Laporan Pengeluaran Riil ?";
							ALert_Edit_Laporan_Riil(pesan);
						}else{
							dialog2.dismiss();	
							finish();
						Daftar_Laporan_Per_Petugas.this.finish();
						
						Intent i = null;
						i = new Intent(Daftar_Laporan_Per_Petugas.this,
								Laporan_Riil.class);
						i.putExtra("id_spt", selectedList.getid_spt());
						i.putExtra("nomor_spt", selectedList.getnomor_SPT());
						i.putExtra("nomor_surat_sppd", selectedList.getnomor_SPPD());
						i.putExtra("nip", selectedList.getnip());
						i.putExtra("nama_pegawai", selectedList.getnama_pegawai());
						i.putExtra("jabatan", selectedList.getjabatan());
						i.putExtra("golongan", selectedList.getgolongan());
						i.putExtra("biaya_perj", selectedList.getbiaya_perj());
						i.putExtra("maksud_perj", selectedList.getmaksud_perj());
						i.putExtra("alat_angkutan", selectedList.getalat_angkutan());
						i.putExtra("tempat_brngkt",
								selectedList.gettempat_brngkt());
						i.putExtra("tempat_tujuan",
								selectedList.gettempat_tujuan());
						i.putExtra("lama_perj", selectedList.getlama_perj());
						i.putExtra("tgl_brngkt", selectedList.gettgl_brngkt());
						i.putExtra("tgl_kembali", selectedList.gettgl_kembali());
						i.putExtra("tambh_pengikut1",
								selectedList.gettambh_pengikut1());
						i.putExtra("tambh_pengikut2",
								selectedList.gettambh_pengikut2());
						i.putExtra("tambh_pengikut3",
								selectedList.gettambh_pengikut3());
						i.putExtra("tambh_pengikut4",
								selectedList.gettambh_pengikut4());
						i.putExtra("tambh_pengikut5",
								selectedList.gettambh_pengikut5());
						i.putExtra("tanggal_aktivitas",
								selectedList.gettgl_aktivitas());
						i.putExtra("waktu_aktivitas",
								selectedList.getjam_aktivitas());
						i.putExtra("akun_pembebanan_anggaran",
								selectedList.getakun_anggaran());
						i.putExtra("surat_masuk_dari",
								selectedList.getsurat_masuk_dari());
						i.putExtra("tgl_surat_masuk",
								selectedList.gettgl_surat_spt_masuk());
						i.putExtra("status_laporan_petugas",
								selectedList.getstatus_laporan_petugas());
						i.putExtra("status_rincian_biaya", selectedList.getstatus_rincian());
						i.putExtra("status_riil", selectedList.getstatus_riil());
						startActivity(i);
					

						}
					}
				});

		btn_posting.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				String cek_status_lap_rincian = selectedList
						.getstatus_laporan_petugas();
				String cek_status_rincian = selectedList.getstatus_rincian();
				String cek_status_riil = selectedList.getstatus_riil();
				String no_sppd = selectedList.getnomor_SPPD();
				String nip = selectedList.getnip();

				//String id_sppd = selectedList.getid_sppd();
				//String Cek = String.valueOf(id_sppd);

				if (cek_status_lap_rincian.contains("BELUM")) {
					Toast.makeText(Daftar_Laporan_Per_Petugas.this,
							"Anda Belum Membuat Laporan Perjalanan Dinas",
							Toast.LENGTH_LONG).show();
				} else if (cek_status_rincian.contains("BELUM")
						&& cek_status_riil.contains("BELUM")) {
					String pesan = "Anda Belum Membuat Laporan Perincian Biaya dan Laporan Pengeluaran Riil";
					alert_posting(pesan);
				} else if (cek_status_rincian.contains("BELUM")) {
					String pesan = "Anda Belum Membuat Laporan Perincian Biaya";
					alert_posting(pesan);

				} else if (cek_status_riil.contains("BELUM")) {
					String pesan = "Anda Belum Membuat Laporan Pengeluaran Biaya Riil";
					alert_posting(pesan);

				} else {
					String pesan = "Data Sudah Lengkap, Posting Data ?";
					alert_posting(pesan);
					//ngeposting(no_sppd, nip);
				}

			}
		});
	}

	private void alert_posting(String message) {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setMessage(message)
				.setTitle("Informasi")
				.setCancelable(false)
				.setIcon(R.drawable.ic_info_outline_24dp)
				.setNegativeButton("Batal",
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int id) {
								dialog.dismiss();

							}
						})
				.setPositiveButton("Posting",
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int id) {
								String no_sppd = selectedList.getnomor_SPPD();
								String nip = selectedList.getnip();
								ngeposting(no_sppd, nip);
							}
						});
		AlertDialog alert = builder.create();
		alert.show();
	}
	
	private void showAlert(String message) {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setMessage(message)
				.setTitle("Informasi")
				.setCancelable(false)
				.setIcon(R.drawable.ic_info_outline_24dp)
				.setPositiveButton("Coba Lagi",
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int id) {
								dialog.dismiss();
								finish();
								startActivity(getIntent());
								
							}
						});
		AlertDialog alert = builder.create();
		alert.show();
	}

	private void info_pesan(String message) {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setMessage(message)
				.setTitle("Informasi")
				.setCancelable(false)
				.setIcon(R.drawable.ic_info_outline_24dp)
				.setPositiveButton("Mengerti",
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int id) {
								dialog.dismiss();
							}
						});
		AlertDialog alert = builder.create();
		alert.show();
	}
	
	private void showAlert_Khusus_Lap(String message) {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setMessage(message)
				.setTitle("Informasi")
				.setCancelable(false)
				.setIcon(R.drawable.ic_info_outline_24dp)
				.setPositiveButton("Ok",
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int id) {
								dialog.dismiss();								
								
							}
						});
		AlertDialog alert = builder.create();
		alert.show();
	}
	
	private void ALert_Edit_Laporan_Perjalanan_Dinas(String message) {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setMessage(message)
				.setTitle("Informasi")
				.setCancelable(false)
				.setIcon(R.drawable.ic_info_outline_24dp)
				.setPositiveButton("Edit Data",
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int id) {								
								dialog.dismiss();							
								finish();
								Daftar_Laporan_Per_Petugas.this.finish();								
								Intent i = null;
								i = new Intent(Daftar_Laporan_Per_Petugas.this,
										Pembuatan_Lap_Setelah_Perj_Dinas.class);
								i.putExtra("id_spt", selectedList.getid_spt()
										);
								i.putExtra("nomor_spt", selectedList.getnomor_SPT()
										);
								i.putExtra("nomor_surat_sppd", selectedList
										.getnomor_SPPD());
								i.putExtra("nip", selectedList.getnip());
								i.putExtra("nama_pegawai", selectedList
										.getnama_pegawai());
								i.putExtra("jabatan", selectedList.getjabatan()
										);
								i.putExtra("golongan", selectedList.getgolongan()
										);
								i.putExtra("biaya_perj", selectedList.getbiaya_perj()
										);
								i.putExtra("maksud_perj", selectedList.getmaksud_perj());
								i.putExtra("alat_angkutan",
										selectedList.getalat_angkutan());
								i.putExtra("tempat_brngkt",
										selectedList.gettempat_brngkt());
								i.putExtra("tempat_tujuan",
										selectedList.gettempat_tujuan());
								i.putExtra("lama_perj", selectedList.getlama_perj());
								i.putExtra("tgl_brngkt", selectedList.gettgl_brngkt());
								i.putExtra("tgl_kembali", selectedList.gettgl_kembali());
								i.putExtra("tambh_pengikut1",
										selectedList.gettambh_pengikut1());
								i.putExtra("tambh_pengikut2",
										selectedList.gettambh_pengikut2());
								i.putExtra("tambh_pengikut3",
										selectedList.gettambh_pengikut3());
								i.putExtra("tambh_pengikut4",
										selectedList.gettambh_pengikut4());
								i.putExtra("tambh_pengikut5",
										selectedList.gettambh_pengikut5());
								i.putExtra("tanggal_aktivitas",
										selectedList.gettgl_aktivitas());
								i.putExtra("waktu_aktivitas",
										selectedList.getjam_aktivitas());
								i.putExtra("akun_pembebanan_anggaran",
										selectedList.getakun_anggaran());
								i.putExtra("surat_masuk_dari",
										selectedList.getsurat_masuk_dari());
								i.putExtra("tgl_surat_masuk",
										selectedList.gettgl_surat_spt_masuk());
								i.putExtra("status_laporan_petugas",
										selectedList.getstatus_laporan_petugas());
								//------------------------
								i.putExtra("nip_pembuatlaporanperj",
										selectedList.getnip_pembuatlaporanperj());
								i.putExtra("nomor_spt_laporanperj",
										selectedList.getnomor_spt_laporanperj());
								i.putExtra("hasil_pertemuan",
										selectedList.gethasil_pertemuan());
								i.putExtra("masalah",
										selectedList.getmasalah());
								i.putExtra("saran",
										selectedList.getsaran());
								i.putExtra("lain_lain",
										selectedList.getlain_lain());
								i.putExtra("tgl_pembuatan_laporan",
										selectedList.gettgl_pembuatan_laporan());
								
								
								startActivity(i);
								
							}
						});
		builder.setNegativeButton("Tidak",
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int id) {
								dialog.dismiss();								
								
							}
						});
		AlertDialog alert = builder.create();
		alert.show();
	}
	
	private void ALert_Edit_Laporan_Rincian(String message) {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setMessage(message)
				.setTitle("Informasi")
				.setCancelable(false)
				.setIcon(R.drawable.ic_info_outline_24dp)
				.setPositiveButton("Edit Data",
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int id) {								
								dialog.dismiss();							
								finish();
								Daftar_Laporan_Per_Petugas.this.finish();								
								Intent i = null;
								i = new Intent(Daftar_Laporan_Per_Petugas.this,
										Edit_Laporan_Rincian_Biaya.class);
								i.putExtra("id_spt", selectedList.getid_spt()
										);
								i.putExtra("nomor_spt", selectedList.getnomor_SPT()
										);
								i.putExtra("nomor_surat_sppd", selectedList
										.getnomor_SPPD());
								i.putExtra("nip", selectedList.getnip());
								i.putExtra("nama_pegawai", selectedList
										.getnama_pegawai());
								i.putExtra("jabatan", selectedList.getjabatan()
										);
								i.putExtra("golongan", selectedList.getgolongan()
										);
								i.putExtra("biaya_perj", selectedList.getbiaya_perj()
										);
								i.putExtra("maksud_perj", selectedList.getmaksud_perj());
								i.putExtra("alat_angkutan",
										selectedList.getalat_angkutan());
								i.putExtra("tempat_brngkt",
										selectedList.gettempat_brngkt());
								i.putExtra("tempat_tujuan",
										selectedList.gettempat_tujuan());
								i.putExtra("lama_perj", selectedList.getlama_perj());
								i.putExtra("tgl_brngkt", selectedList.gettgl_brngkt());
								i.putExtra("tgl_kembali", selectedList.gettgl_kembali());
								i.putExtra("tambh_pengikut1",
										selectedList.gettambh_pengikut1());
								i.putExtra("tambh_pengikut2",
										selectedList.gettambh_pengikut2());
								i.putExtra("tambh_pengikut3",
										selectedList.gettambh_pengikut3());
								i.putExtra("tambh_pengikut4",
										selectedList.gettambh_pengikut4());
								i.putExtra("tambh_pengikut5",
										selectedList.gettambh_pengikut5());
								i.putExtra("tanggal_aktivitas",
										selectedList.gettgl_aktivitas());
								i.putExtra("waktu_aktivitas",
										selectedList.getjam_aktivitas());
								i.putExtra("akun_pembebanan_anggaran",
										selectedList.getakun_anggaran());
								i.putExtra("surat_masuk_dari",
										selectedList.getsurat_masuk_dari());
								i.putExtra("tgl_surat_masuk",
										selectedList.gettgl_surat_spt_masuk());
								i.putExtra("status_laporan_petugas",
										selectedList.getstatus_laporan_petugas());
								i.putExtra("status_rincian_biaya", selectedList.getstatus_rincian());
								//------------------------
								i.putExtra("nip_pembuatlaporanperj",
										selectedList.getnip_pembuatlaporanperj());
								i.putExtra("nomor_spt_laporanperj",
										selectedList.getnomor_spt_laporanperj());
								i.putExtra("hasil_pertemuan",
										selectedList.gethasil_pertemuan());
								i.putExtra("masalah",
										selectedList.getmasalah());
								i.putExtra("saran",
										selectedList.getsaran());
								i.putExtra("lain_lain",
										selectedList.getlain_lain());
								i.putExtra("tgl_pembuatan_laporan",
										selectedList.gettgl_pembuatan_laporan());
								
								
								startActivity(i);
								
							}
						});
		builder.setNegativeButton("Tidak",
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int id) {
								dialog.dismiss();	
								
								
							}
						});
		AlertDialog alert = builder.create();
		alert.show();
	}
	
	private void ALert_Edit_Laporan_Riil(String message) {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setMessage(message)
				.setTitle("Informasi")
				.setCancelable(false)
				.setIcon(R.drawable.ic_info_outline_24dp)
				.setPositiveButton("Edit Data",
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int id) {								
								dialog.dismiss();							
								finish();
								Daftar_Laporan_Per_Petugas.this.finish();								
								Intent i = null;
								i = new Intent(Daftar_Laporan_Per_Petugas.this,
										Edit_Laporan_Riil.class);
								i.putExtra("id_spt", selectedList.getid_spt()
										);
								i.putExtra("nomor_spt", selectedList.getnomor_SPT()
										);
								i.putExtra("nomor_surat_sppd", selectedList
										.getnomor_SPPD());
								i.putExtra("nip", selectedList.getnip());
								i.putExtra("nama_pegawai", selectedList
										.getnama_pegawai());
								i.putExtra("jabatan", selectedList.getjabatan()
										);
								i.putExtra("golongan", selectedList.getgolongan()
										);
								i.putExtra("biaya_perj", selectedList.getbiaya_perj()
										);
								i.putExtra("maksud_perj", selectedList.getmaksud_perj());
								i.putExtra("alat_angkutan",
										selectedList.getalat_angkutan());
								i.putExtra("tempat_brngkt",
										selectedList.gettempat_brngkt());
								i.putExtra("tempat_tujuan",
										selectedList.gettempat_tujuan());
								i.putExtra("lama_perj", selectedList.getlama_perj());
								i.putExtra("tgl_brngkt", selectedList.gettgl_brngkt());
								i.putExtra("tgl_kembali", selectedList.gettgl_kembali());
								i.putExtra("tambh_pengikut1",
										selectedList.gettambh_pengikut1());
								i.putExtra("tambh_pengikut2",
										selectedList.gettambh_pengikut2());
								i.putExtra("tambh_pengikut3",
										selectedList.gettambh_pengikut3());
								i.putExtra("tambh_pengikut4",
										selectedList.gettambh_pengikut4());
								i.putExtra("tambh_pengikut5",
										selectedList.gettambh_pengikut5());
								i.putExtra("tanggal_aktivitas",
										selectedList.gettgl_aktivitas());
								i.putExtra("waktu_aktivitas",
										selectedList.getjam_aktivitas());
								i.putExtra("akun_pembebanan_anggaran",
										selectedList.getakun_anggaran());
								i.putExtra("surat_masuk_dari",
										selectedList.getsurat_masuk_dari());
								i.putExtra("tgl_surat_masuk",
										selectedList.gettgl_surat_spt_masuk());
								i.putExtra("status_laporan_petugas",
										selectedList.getstatus_laporan_petugas());
								//------------------------
								i.putExtra("nip_pembuatlaporanperj",
										selectedList.getnip_pembuatlaporanperj());
								i.putExtra("nomor_spt_laporanperj",
										selectedList.getnomor_spt_laporanperj());
								i.putExtra("hasil_pertemuan",
										selectedList.gethasil_pertemuan());
								i.putExtra("masalah",
										selectedList.getmasalah());
								i.putExtra("saran",
										selectedList.getsaran());
								i.putExtra("lain_lain",
										selectedList.getlain_lain());
								i.putExtra("tgl_pembuatan_laporan",
										selectedList.gettgl_pembuatan_laporan());
								
								
								startActivity(i);
								
							}
						});
		builder.setNegativeButton("Tidak",
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int id) {
								dialog.dismiss();								
								
							}
						});
		AlertDialog alert = builder.create();
		alert.show();
	}
	
	private void showprogress_download(String a) {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setMessage(a)
				.setTitle("Informasi")
				.setCancelable(false)
				.setIcon(R.drawable.ic_info_outline_24dp)
				.setPositiveButton("Ok",
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int id) {
								dialog.dismiss();
								finish();
								startActivity(getIntent());
								
							}
						});
		AlertDialog alert = builder.create();
		alert.show();
	}

	private void ngeposting(String no_sppd, String nip) {

		class posting extends AsyncTask<String, Void, String> {

			ProgressDialog tampilloading;
			Java_Connection ruc = new Java_Connection();

			@Override
			protected void onPreExecute() {
				super.onPreExecute();
				tampilloading = ProgressDialog.show(
						Daftar_Laporan_Per_Petugas.this, "", "Sedang Dalam Proses Posting\nTunggu Sebentar...",
						true, true);
                tampilloading.setCancelable(false);
			}

			@Override
			protected void onPostExecute(String s) {
				super.onPostExecute(s);
				tampilloading.dismiss();
				//Toast.makeText(Daftar_Laporan_Per_Petugas.this,
					//	"Posting Sukses", Toast.LENGTH_LONG).show();
				finish();
				startActivity(getIntent());
			}

			@Override
			protected String doInBackground(String... params) {
				HashMap<String, String> data = new HashMap<String, String>();
				data.put("no_sppd", params[0]);
				data.put("nip", params[1]);

				String result = ruc.sendPostRequest(Koneksi.posting_url, data);
				return result;

			}
		}

		posting ru = new posting();
		ru.execute(no_sppd, nip);
	}

	@Override
	protected Dialog onCreateDialog(int id) {
		String id_sppd = selectedList.getid_sppd();
		String id_spt = selectedList.getid_spt();
		switch (id) {

		case progress_bar_type_spt:
			loading = new ProgressDialog(this);
			loading.setMessage("Downloading file. Please Wait\nlaporan_surat_perintah_tugas_"
					+ id_spt + ".pdf");
			loading.setIndeterminate(false);
			loading.setMax(100);
			loading.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
			loading.setCancelable(false);
			loading.show();
			return loading;

		case progress_bar_type_sppd:
			loading = new ProgressDialog(this);
			loading.setMessage("Downloading file. Please Wait\nlaporan_sppd_"
					+ id_sppd + ".pdf");
			loading.setIndeterminate(false);
			loading.setMax(100);
			loading.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
			loading.setCancelable(false);
			loading.show();
			return loading;
		default:

			return null;
		}
	}

	@SuppressLint("SdCardPath")
	class DownloadFile_SPT extends AsyncTask<String, String, String>

	{
		@Override
		@SuppressWarnings("deprecation")
		protected void onPreExecute() {
			super.onPreExecute();
			showDialog(progress_bar_type_spt);
			
		}

		@Override
		protected String doInBackground(String... f_url) {
			int count;
			String id_spt = selectedList.getid_spt();

			try {

				URL url = new URL(f_url[0]);

				URLConnection connection = url.openConnection();
				connection.connect();

				int lenghOfFile = connection.getContentLength();
				InputStream input = new BufferedInputStream(url.openStream(),
						8192);

				OutputStream output = new FileOutputStream(
						"/sdcard/Download/laporan_surat_perintah_tugas_"
								+ id_spt + ".pdf");
				byte data[] = new byte[1024];
				long total = 0;

				while ((count = input.read(data)) != -1) {
					total += count;
					publishProgress("" + (int) ((total * 100) / lenghOfFile));
					output.write(data, 0, count);
				}
				output.flush();
				output.close();
				input.close();
			} catch (Exception e) {
				Log.e("Error : ", e.getMessage());
			
				String a = "Download Gagal"+e.getMessage();
				showAlert(a);
			}
			return null;
		}

		@Override
		protected void onProgressUpdate(String... progress) {
			loading.setProgress(Integer.parseInt(progress[0]));
		}

		@Override
		@SuppressWarnings("deprecation")
		protected void onPostExecute(String file_url) {
			dismissDialog(progress_bar_type_spt);
			String pesan = "Download Berhasil\nSilahkan dibuka di Folder Download";
			showprogress_download(pesan);
		}
	}

	@SuppressLint("SdCardPath")
	class DownloadFile_SPPD extends AsyncTask<String, String, String>

	{
		@Override
		@SuppressWarnings("deprecation")
		protected void onPreExecute() {
			super.onPreExecute();
			showDialog(progress_bar_type_sppd);
		}

		@Override
		protected String doInBackground(String... f_url) {
			int count;
			String id_sppd = selectedList.getid_sppd();

			try {

				// KURANG GETS POST

				URL url = new URL(f_url[0]);

				URLConnection connection = url.openConnection();
				connection.connect();

				int lenghOfFile = connection.getContentLength();
				InputStream input = new BufferedInputStream(url.openStream(),
						8192);

				OutputStream output = new FileOutputStream(
						"/sdcard/Download/laporan_sppd_" + id_sppd + ".pdf");
				byte data[] = new byte[1024];
				long total = 0;

				while ((count = input.read(data)) != -1) {
					total += count;
					publishProgress("" + (int) ((total * 100) / lenghOfFile));
					output.write(data, 0, count);
				}
				output.flush();
				output.close();
				input.close();
			} catch (Exception e) {
				Log.e("Error : ", e.getMessage());
				String a = "Download Gagal"+e.getMessage();
				showAlert(a);
			}
			return null;
		}

		@Override
		protected void onProgressUpdate(String... progress) {
			loading.setProgress(Integer.parseInt(progress[0]));
		}

		@Override
		@SuppressWarnings("deprecation")
		protected void onPostExecute(String file_url) {
			dismissDialog(progress_bar_type_sppd);
			String pesan = "Download Berhasil \nSilahkan dibuka di Folder Download";
			showprogress_download(pesan);
			
			// String imagePath =
			// Environment.getExternalStorageDirectory().toString() +
			// "/prints_spt.pdf";
			// laylistrecent.setBackgroundDrawable(Drawable.createFromPath(imagePath));
		}
	}
	public void kembali_activity(View view){
		super.onBackPressed();
	}
}
