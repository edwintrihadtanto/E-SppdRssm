package com.e_sppd_rssm;

import java.io.BufferedInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import koneksi.JSONParser;
import koneksi.Koneksi;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.Html;
import android.text.TextWatcher;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.e_sppd.rssm.R;

public class Login_Activity extends Activity  {
	private final static String TAG = "Login_Activity";

	public ImageView ImageView_Help;
	public CheckBox checkbox_pass;
	public EditText edit_pass, edit_nip;

	private ProgressDialog progressBarNya;
	JSONParser classJsonParser = new JSONParser();
	private TextView cek_versi_apk, infoversibaru, text_lupapass;

	ConnectivityManager conMgr;
	public static final String nippegawai 		= "nip";
	private static final String versi 			= "versi";
	private static final String TAG_SUKSES 		= "berhasil";
	private static final String TAG_PESAN 		= "tampilkan_pesan";
	private static final String TAG_SUKSES2 	= "success";
	private static final String TAG_PESAN2 		= "message";
	private static final String TAG_VERSI_BARU 	= "kirim_versinya";	
	private static final String Security_Level 	= "level";
	private static final int progress_DOWNLOAD 	= 0;
	public final static String TAG_NIP 			= "nip";
	public final static String TAG_NAMA_PEGAWAI = "nama_pegawai";
	public final static String TAG_JABATAN 		= "jabatan";
	public final static String TAG_GOLONGAN 	= "golongan";
	public final static String TAG_PASSWORD 	= "password";

	private static final String Info_Pesan 		= "pesan";
	private static final String Sukses_Simpan	= "sukses_simpan";
	private static final String Pesannya		= "pesannya";
	private String get_pesan;
	private ListView listView;
	private ArrayAdapter<String> arrayAdapter;
	private String[] daftarversiaplikasi={
			"Versi 2.1",
			"Versi 2.0",
			"Versi 1.3.3",
			"Versi 1.3.2",
			"Versi 1.3.1",
			"Versi 1.2",
			"Versi 1.1",
			"Versi 1.0"};
	private String nip, nama_pegawai, jabatan, golongan, password,  kirim_versi;
	SharedPreferences sharedpreferences;
	Boolean session_1 = false;
	Boolean session_2 = false;
	public static final String my_shared_preferences = "my_shared_preferences";
	public static final String session_status_level1 = "session_status_level1";
	public static final String session_status_level2 = "session_status_level2";
	private LinearLayout text_berjalan;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login_activity);
		conMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
			{
				if (conMgr.getActiveNetworkInfo() != null
						&& conMgr.getActiveNetworkInfo().isAvailable()
						&& conMgr.getActiveNetworkInfo().isConnected()) {
				} else {
					Toast.makeText(getApplicationContext(), "Tidak Ada Koneksi Internet",
							Toast.LENGTH_LONG).show();
				}
		}

		checkbox_pass 	= (CheckBox) findViewById(R.id.checkbox_pass);
		edit_pass 		= (EditText) findViewById(R.id.edit_pass);
		edit_nip 		= (EditText) findViewById(R.id.edit_nip);
		cek_versi_apk 	= (TextView) findViewById(R.id.cek_versi_apk);
		infoversibaru 	= (TextView) findViewById(R.id.infoversibaru);
		ImageView_Help  = (ImageView) findViewById(R.id.ImageView_Help);
		text_lupapass 	= (TextView) findViewById(R.id.text_lupapass);

		ImageView_Help.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
			//String pesan = "Sipp Mantap";
			//showAlert(pesan);
				Intent i = null;

				i = new Intent(Login_Activity.this,
						Tampil_Bantuan.class);
				startActivity(i);				
			}
		});
		text_lupapass.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				lupa_password();

			}
		});
		infoversibaru.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				tampilinformasi();
			
			}
		});

		LinearLayout text_berjalan = (LinearLayout)findViewById(R.id.textberjalan_login);
		String pesan_infoversi = "::Klik Disini ^_^ Informasi Update Versi Terbaru::";
		//+ versi;
		setticker(text_berjalan, pesan_infoversi, this);

		text_berjalan.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				tampilinformasi();
			}
		});

		cek_versi_apk.setText("2.0");
		kirim_versi = cek_versi_apk.getText().toString();
		//edit_nip.setText("303-03081992-052017-8776");
		//edit_pass.setText("edwin");
		//edit_nip.setText("12345");
		//edit_pass.setText("admin12345");
		// -----------------------------SCRIPT SHOW / HIDE
		// PASSWORD---------------------------- //

		// Cek session login jika TRUE maka langsung buka MainActivityBaru_Admin
		sharedpreferences = getSharedPreferences(my_shared_preferences, Context.MODE_PRIVATE);
		session_1 		= sharedpreferences.getBoolean(session_status_level1, false);
		session_2 		= sharedpreferences.getBoolean(session_status_level2, false);
		nip 			= sharedpreferences.getString(TAG_NIP, null);
		nama_pegawai 	= sharedpreferences.getString(TAG_NAMA_PEGAWAI, null);
		jabatan			= sharedpreferences.getString(TAG_JABATAN, null);
		golongan 		= sharedpreferences.getString(TAG_GOLONGAN, null);
		password		= sharedpreferences.getString(TAG_PASSWORD, null);
		//kirim_versi = sharedpreferences.getString(versi, null);

		if (session_1) {
			Intent intent = new Intent(Login_Activity.this, MainActivityBaru_Admin.class);
			intent.putExtra(TAG_NIP, nip);
			intent.putExtra(TAG_NAMA_PEGAWAI, nama_pegawai);
			intent.putExtra(TAG_JABATAN, jabatan);
			intent.putExtra(TAG_GOLONGAN, golongan);
			intent.putExtra(TAG_PASSWORD, password);
			intent.putExtra(versi, kirim_versi);
			finish();
			startActivity(intent);
		}else if (session_2) {
			Intent intent = new Intent(Login_Activity.this, MainActivityBaru_Petugas.class);
			intent.putExtra(TAG_NIP, nip);
			intent.putExtra(TAG_NAMA_PEGAWAI, nama_pegawai);
			intent.putExtra(TAG_JABATAN, jabatan);
			intent.putExtra(TAG_GOLONGAN, golongan);
			intent.putExtra(TAG_PASSWORD, password);
			intent.putExtra(versi, kirim_versi);
			finish();
			startActivity(intent);
		}
		checkbox_pass.setOnCheckedChangeListener(new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(CompoundButton buttonView,
					boolean isChecked) {
				// checkbox status is changed from uncheck to checked.
				if (!isChecked) {
					// show password
					edit_pass.setTransformationMethod(PasswordTransformationMethod.getInstance());
					edit_pass.setHint("Tampilkan Password");
					checkbox_pass.setHint("Tampilkan Password");
				} else {
					// hide password
					edit_pass.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
					edit_pass.setHint("Sembunyikan Password");
					checkbox_pass.setHint("Sembunyikan Password");
				}
			}
		});


		
		
		// PENGECEKAN VALIDASI KERENNN
		edit_nip.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence s, int start, int before,
					int count) {

			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
			}

			@Override
			public void afterTextChanged(Editable s) {
				validasi_nip(edit_nip);
			}
		});

		edit_pass.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence s, int start, int before,
					int count) {
			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
			}

			@Override
			public void afterTextChanged(Editable s) {
				validasi_pass(edit_pass);
			}
		});

	}
	private void lupa_password() {
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		dialog.setContentView(R.layout.dialog_lupa_password);
		final TextView textcp1 = (TextView)dialog.findViewById(R.id.textcp1);
		final TextView textcp2 = (TextView)dialog.findViewById(R.id.textcp2);

		textcp1.setOnClickListener(new Button.OnClickListener() {
			public void onClick(View v) {
				//number = inputan dari editText
				String toDial="tel:"+textcp1.getText().toString();
				startActivity(new Intent(Intent.ACTION_DIAL,Uri.parse(toDial)));
			}
		});

		textcp2.setOnClickListener(new Button.OnClickListener() {
			public void onClick(View v) {
				//number = inputan dari editText
				String toDial2="tel:"+textcp2.getText().toString();
				startActivity(new Intent(Intent.ACTION_DIAL,Uri.parse(toDial2)));
			}
		});
		dialog.show();
	}
	private void tampilinformasi() {
		final Dialog dialog = new Dialog(this);
		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		dialog.setContentView(R.layout.dialog_informasi_update_versi);

		listView	 = (ListView) dialog.findViewById(R.id.listupdate);
		arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_activated_1,daftarversiaplikasi);
		listView.setAdapter(arrayAdapter);

		listView.setOnItemClickListener(new AdapterView.OnItemClickListener()
			{
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				String message="Anda Memilih "+((TextView)view).getText();
				String ambil = ((TextView)view).getText().toString();

				String versikedelapan = "Versi 2.1";
				String versiketujuh = "Versi 2.0";
				String versikeenam 	= "Versi 1.3.3";
				String versikelima 	= "Versi 1.3.2";
				String versikeempat = "Versi 1.3.1";
				String versiketiga 	= "Versi 1.2";
				String versikedua 	= "Versi 1.1";
				String versipertama = "Versi 1.0";
				if (ambil == versipertama){
					String isinya= "" +
							"- Aplikasi E-SPDD merupakan Aplikasi Pertama berbasis Mobile yang memiliki fungsi " +
							"untuk mempermudah " +
							"kinerja pegawai dalam pembuatan Laporan SPPD, Laporan Rincian Perjalanan Dinas, " +
							"serta Laporan Rincian Perjalanan Dinas\n";
					info_versi(isinya);
				}else if (ambil == versikedua){
					String isinya= "" +
							"- Memperbaiki masalah bugs laporan pada versi sebelumnya\n";
					info_versi(isinya);
				}else if (ambil == versiketiga){
					String isinya= "" +
							"- Memperbaiki masalah bugs register pada versi sebelumnya\n";
					info_versi(isinya);
				}else if (ambil == versikeempat){
					String isinya= "" +
							"- Memperbaiki masalah bugs uploads foto pada versi sebelumnya\n";
					info_versi(isinya);
				}else if (ambil == versikelima){
					String isinya= "" +
							"- Memperbaiki masalah bugs downloads laporan pada versi sebelumnya\n";
					info_versi(isinya);
				}else if (ambil == versikeenam){
					String isinya= "" +
							"- Memperbaiki masalah bugs pada versi sebelumnya\n" +
							"- Penambahan Fitur Baru Kamera\n" +
							"- Design Baru\n" +
							"- Fungsi-fungsi Baru\n" +
							"- Dapat Melakukan Edit Data Rincian dan Rill Biaya\n";
					info_versi(isinya);
				}else if (ambil == versiketujuh){
					String isinya= "" +
							"- Tampilan Baru, Lebih Simple dan Mudah Pengoperasian\n" +
							"- Penambahan Fitur Calling Problem\n" +
							"- Memperbaiki Permasalahan Beberapa Bugs Dari Versi Sebelumnya\n" +
							"- Penambahan Session Login, dimana Pengguna Tidak Diperlukan Login Lagi\n" +
							"- Penambahan Tombol Hapus Pada Sesi Pembuatan Laporan Perincian Biaya";
					info_versi(isinya);

				}else if (ambil == versikedelapan){
					String a= "Versi 2.1  Comming Soon";
					Toast.makeText(getApplicationContext(), a,
							Toast.LENGTH_LONG).show();
					String isinya= "::: Berdasarkan Kritik dan Saran Dari Pengguna Aplikasi E-SPPD :::\n" +
							"- Penggabungan Laporan Perjalanan Dinas Berkelompok sehingga " +
							"Hanya Perlu Membuat Satu Laporan Perjalanan Dinas Dalam (SPT Yang Berkelompok)\n" +
							"- Penambahan Tutorial Video Pengoperasian Aplikasi E-SPPD";
					info_versi_commingsoon(isinya);
				}else{
					String isinya= "Tidak Ada Informasi Versi";
					info_versi(isinya);
				}
				Toast.makeText(getApplicationContext(), message,
						Toast.LENGTH_LONG).show();
			}
		});
		dialog.show();
	}

	public boolean validasi_nip(EditText editText) {

		edit_nip.setError(null);
		// length 0 means there is no text
		if (edit_nip.length() == 0) {
			editText.setError(Html
					.fromHtml("<font color='red'>NIP/NPK Tidak Boleh Kosong</font>"));
			return false;
		}
		return true;
	}

	public boolean validasi_pass(EditText editText) {

		edit_pass.setError(null);
		if (edit_pass.length() == 0) {
			editText.setError(Html
					.fromHtml("<font color='red'>Password Tidak Boleh Kosong</font>"));
			return false;
		}
		return true;
	}
	
	private boolean terkoneksi_roaming(Context mContext) {
		ConnectivityManager cm = (ConnectivityManager) mContext
				.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo netInfo = cm.getActiveNetworkInfo();
		if (netInfo != null && netInfo.isConnectedOrConnecting()) {
			Toast.makeText(
					getApplication(),
					"Koneksi Internet Anda : "
							+ netInfo.getTypeName() + " "
							+ netInfo.getSubtypeName(), Toast.LENGTH_SHORT)
					.show();
			return true;
		}
		return false;

	}

	public void gotoregister (View view){

		Intent i = new Intent(Login_Activity.this,Register_Activity.class);
		startActivity(i);
		finish();
	}
	public void ceklogin(View view) {
		
		if (!terkoneksi_roaming(Login_Activity.this)) {
			String a = "Tidak ada sambungan Internet.\nPastikan Wi-fi atau Data Seluler aktif, lalu coba lagi";
			show_warning(a);
			return;
		
		} else if (edit_nip.length() < 1) {
			Toast.makeText(Login_Activity.this,
					"Nomor Induk Pegawai Belum Diisi", Toast.LENGTH_LONG)
					.show();
			return;
		} else if (edit_pass.length() < 1) {
			Toast.makeText(Login_Activity.this, "Password Belum Diisi",
					Toast.LENGTH_LONG).show();
			return;
		} else if ((edit_nip.getText().toString().contains("ipde")) || (edit_nip.getText().toString().contains("su"))
				|| (edit_nip.getText().toString().contains("admin")) || (edit_nip.getText().toString().contains("123456789"))
				|| (edit_nip.getText().toString().contains("qwerty"))|| (edit_nip.getText().toString().contains("%"))
				|| (edit_pass.getText().toString().contains("ipde2017"))) {
			/*
			String nip = "ipde";
			String kirim_versi = cek_versi_apk.getText().toString();
			Intent intent = new Intent(Login_Activity.this,
					Main_Activity_SUPERUSER.class);
			intent.putExtra(nippegawai, nip);
			intent.putExtra(versi, kirim_versi);
			startActivity(intent);
			finish();
*/
			Toast.makeText(Login_Activity.this, "Aplikasi E-SPPD Tidak Bisa DiInjeksi\nCoba Lagi Dilain Kesempatan",
					Toast.LENGTH_LONG).show();
			return;

		} else {
			// String nip = edit_nip.getText().toString().trim();
			// String pass = edit_pass.getText().toString().trim();
			// login(nip, pass);
			new Cek_Versi_APK().execute();
			// new MencobaLogin().execute();
			return;
		}

	}

	public class Cek_Versi_APK extends AsyncTask<String, String, String> {

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			
			progressBarNya = new ProgressDialog(Login_Activity.this);
			progressBarNya.setMessage("Sedang Dalam Proses Login...");
			progressBarNya.setIndeterminate(false);
			progressBarNya.setCancelable(false);
			progressBarNya.show();
		}

		@Override
		protected String doInBackground(String... args) {
			int jikaSukses;

			String Kirim_Cek_Versi_APK = cek_versi_apk.getText().toString();
			String responseString = null; 			
			try {

				List<NameValuePair> namaDanPassword = new ArrayList<NameValuePair>();
				namaDanPassword.add(new BasicNameValuePair("kirim_versi",
						Kirim_Cek_Versi_APK));
				Log.d("Proses Cek Versi!", "dimulai");

				JSONObject jsonObjectNya = classJsonParser.makeHttpRequest(
						Koneksi.CEK_VERSI, "POST", namaDanPassword);

				// priksa log jawaban dari JSON
				Log.d("Coba login", jsonObjectNya.toString());

				// apa kata JSON tentang TAG_SUKSES
				// TAG_SUKSES = "berhasil";
				jikaSukses = jsonObjectNya.getInt(TAG_SUKSES);
				// cek_level = jsonObjectNya.getInt(Security_Level);

				if (jikaSukses == 1) {

					Log.d("Versi Benar", jsonObjectNya.getString(TAG_PESAN));

					return jsonObjectNya.getString(TAG_PESAN);
					
				} else {
					String Info_versi = jsonObjectNya.getString(TAG_VERSI_BARU);
					get_pesan = jsonObjectNya.getString(Info_Pesan);
					Log.d("Perlu Versi Baru",jsonObjectNya.getString(TAG_PESAN));
					return jsonObjectNya.getString(TAG_PESAN);
					
				}
			} catch (JSONException e) {
				responseString = e.toString();					
			} catch (Exception e){
				responseString = e.toString();
			}

			return responseString;

		}

		@Override
		protected void onPostExecute(String urlFileNya) {
			// kalau sudah selesai di gunakan, matikanlah
			// progressbar_nya dengan metode dismiss();
			progressBarNya.dismiss();
			String ambil = urlFileNya.toString().trim();
			if (ambil != null) {
				if (ambil.contains("Silahkan")){
					informasi_versi(get_pesan);
				}else if (ambil.contains("Maintenance")) {
					//String pesan = "Sedang Dalam Maintenance Sistem ... !!!";
					info_maintenance(urlFileNya);
				}else if (urlFileNya.contains("Wajib")) {
					info_download(get_pesan);
				}else{
					new MencobaLogin().execute();
				}							
			}else{
				String a = "Sambungan Internet Terputus.\nPastikan Wi-fi atau Data Seluler aktif, lalu coba lagi";
				show_warning(a);
			}

		}

	}
	private void info_versi_commingsoon(String message) {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setMessage(message)
				.setTitle("Comming Soon")
				.setCancelable(false)
				.setIcon(R.drawable.ic_warning_black)
				.setPositiveButton("Bye Bye",
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int id) {
								dialog.dismiss();
							}
						});
		AlertDialog alert = builder.create();
		alert.show();
	}
	private void info_versi(String message) {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setMessage(message)
				.setTitle("Informasi Versi")
				.setCancelable(false)
				.setIcon(R.drawable.ic_info_outline_24dp)
				.setPositiveButton("Terima Kasih",
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int id) {
								dialog.dismiss();
							}
						});
		AlertDialog alert = builder.create();
		alert.show();
	}
	private void info_maintenance(String message) {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setMessage(message)
				.setTitle("Informasi")
				.setCancelable(false)
				.setIcon(R.drawable.ic_info_outline_24dp)
				.setPositiveButton("Ok",
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int id) {
								dialog.dismiss();
								Login_Activity.this.finish();
								finish();

							}
						});
		AlertDialog alert = builder.create();
		alert.show();
	}

	private void info_download(String message) {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setMessage(message)
				.setTitle("Tersedia Versi Terbaru !!!")
				.setCancelable(false)
				.setIcon(R.drawable.ic_file_download_black)
				.setPositiveButton("Download",
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int id) {
								dialog.dismiss();
								//e-Sppd.v"+kirim_versi+".apk
								//String kirim_versi = cek_versi_apk.getText().toString();
								//String kirim_versi = "1.3.2";
								String Cek = kirim_versi;
								try {
									new Download_APlikasi().execute(Koneksi.download_apk + "e-Sppd.v"
											+ URLEncoder.encode(Cek, "UTF-8")+".apk");
								} catch (Exception ex) {
									// TODO Auto-generated catch block
									//ex.getMessage();
									ex.printStackTrace();
								}

							}
						})
				.setNegativeButton("Nanti",
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int id) {
								dialog.dismiss();
								Login_Activity.this.finish();
								finish();

							}
						})
				.setNeutralButton("Masuk Website",
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int id) {
								dialog.dismiss();
								Intent in = new Intent();
								in.setAction(Intent.ACTION_VIEW);
								in.addCategory(Intent.CATEGORY_BROWSABLE);
								in.setData(Uri.parse(Koneksi.URL_WEBSITE));
								startActivity(in);

							}
						});
		AlertDialog alert = builder.create();
		alert.show();
	}

	private void informasi_versi(String pesan) {
		AlertDialog.Builder ad = new AlertDialog.Builder(this);
		ad.setTitle("Informasi");
		ad.setMessage(pesan);
		ad.setCancelable(false);
		ad.setIcon(R.drawable.ic_info_outline_24dp);
		ad.setPositiveButton("Download", new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {				
					dialog.dismiss();		
					//e-Sppd.v"+kirim_versi+".apk
					//String kirim_versi = cek_versi_apk.getText().toString();
					//String kirim_versi = "1.3.2";
					String Cek = kirim_versi;
					try {
						
	
						new Download_APlikasi().execute(Koneksi.download_apk + "e-Sppd.v"
								+ URLEncoder.encode(Cek, "UTF-8")+".apk");
	
					} catch (Exception ex) {
						// TODO Auto-generated catch block
						//ex.getMessage();
						ex.printStackTrace();
					
					}
					
			}
		});
		ad.setNegativeButton("Nanti ",
				new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int id) {
						dialog.dismiss();
						new MencobaLogin().execute();
					}
				});
		
		ad.show();
	}
	
	@Override
	protected Dialog onCreateDialog(int id) {
		//String kirim_versi = cek_versi_apk.getText().toString();
		switch (id) {

		case progress_DOWNLOAD:
			progressBarNya = new ProgressDialog(this);
			progressBarNya.setMessage("Downloading file...\ne-Sppd.v"+kirim_versi+".apk");
			progressBarNya.setIndeterminate(false);
			progressBarNya.setMax(100);
			progressBarNya.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
			progressBarNya.setCancelable(false);
			progressBarNya.show();
			return progressBarNya;
		default:

			return null;
		}
	}
	
	//@SuppressLint("SdCardPath")
	private class Download_APlikasi extends AsyncTask<String, String, String>

	{
		@Override
		@SuppressWarnings("deprecation")
		protected void onPreExecute() {
			super.onPreExecute();
			showDialog(progress_DOWNLOAD);
			
		}

		@Override
		protected String doInBackground(String... f_url) {
			int count;
			String responseString = null; 											// 1 
			//String kirim_versi = cek_versi_apk.getText().toString();
			try {

				URL url = new URL(f_url[0]);

				URLConnection connection = url.openConnection();
				connection.connect();

				int lenghOfFile = connection.getContentLength();
				InputStream input = new BufferedInputStream(url.openStream(),
						8192);

				OutputStream output = new FileOutputStream(
						"/sdcard/Download/e-Sppd.v"+kirim_versi+".apk");
				byte data[] = new byte[1024];
				long total = 0;

				while ((count = input.read(data)) != -1) {
					total += count;
					publishProgress("" + (int) ((total * 100) / lenghOfFile));
					output.write(data, 0, count);
				}
				output.flush();
				output.close();
				input.close();
			} catch (ClientProtocolException e) { 	// 2
				responseString = e.toString();		//
			} catch (IOException e) {				//	
				responseString = e.toString();		//3
			}										//
			return responseString;					//4
		}

		@Override
		protected void onProgressUpdate(String... progress) {
			progressBarNya.setProgress(Integer.parseInt(progress[0]));
		}

		@Override
		@SuppressWarnings("deprecation")
		protected void onPostExecute(String file_url) {
			dismissDialog(progress_DOWNLOAD);
			Log.e(TAG, "Respon Dari Server ::: " + "Error");
			
			String pesan1 = "java.net.SocketException: recvfrom failed: ETIMEDOUT (Connection timed out)";
			String pesan2 = "java.net.UnknownHostException: Unable to resolve host";
			
			if (file_url != null){
				if (file_url.contains(pesan2)){
					String info_pesan1 = "Tidak Ada Koneksi Internet\n" +
							"Pastikan Wi-fi atau Data Seluler aktif dan lancar, lalu coba lagi";	
					show_warning(info_pesan1);
				}else if (file_url.contains(pesan1)){
					String info_pesan1 = "Koneksi Sambungan Terputus\n" +
							"Pastikan Wi-fi atau Data Seluler aktif dan lancar, lalu coba lagi";
					show_warning(info_pesan1);
				}else{
					refresh();
				}
				
			//}else if (file_url.equalsIgnoreCase(pesan1)){
			//	String info_pesan2 = "Koneksi Sambungan Terputus\n" +
			//			"Pastikan Wi-fi atau Data Seluler aktif dan lancar, lalu coba lagi";	
			//	showAlert(info_pesan2);	
			}else{
				String info_pesan3 = "Download Berhasil !!!\nSilahkan di Buka Pada Folder Downloads";	
				info(info_pesan3);				
			}
			super.onPostExecute(file_url);				
		}
	}
	public class MencobaLogin extends AsyncTask<String, String, String> {

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			progressBarNya = new ProgressDialog(Login_Activity.this);
			progressBarNya.setMessage("Sedang Dalam Proses Login...");
			progressBarNya.setIndeterminate(false);
			progressBarNya.setIcon(R.drawable.ic_info_outline_24dp);
			progressBarNya.setCancelable(false);
			progressBarNya.show();
		}

		@Override
		protected String doInBackground(String... args) {
		
			int jikaSukses;
			int jikaSukses_SimpanDatabase;
			int cek_level;
			String responseString = null; 	
			String nippegawai 	= edit_nip.getText().toString();
			String passpwgawai 	= edit_pass.getText().toString();
			String Kirim_Cek_Versi_APK = cek_versi_apk.getText().toString();
			
			try {
			
				List<NameValuePair> namaDanPassword = new ArrayList<NameValuePair>();
				namaDanPassword.add(new BasicNameValuePair("nip", nippegawai));
				namaDanPassword.add(new BasicNameValuePair("pass", passpwgawai));
				namaDanPassword.add(new BasicNameValuePair("versi", Kirim_Cek_Versi_APK));
				
				Log.d("requestNya!", "dimulai");
			
				JSONObject jsonObjectNya = classJsonParser.makeHttpRequest
						(Koneksi.LINK_UNTUK_LOGIN_TES, "POST", namaDanPassword);
			
				Log.d("Coba login", jsonObjectNya.toString());

				jikaSukses 				  = jsonObjectNya.getInt(TAG_SUKSES2);
				//jikaSukses_SimpanDatabase = jsonObjectNya.getInt(Sukses_Simpan);

				if (jikaSukses == 1) {
					cek_level 	= jsonObjectNya.getInt(Security_Level);
					Log.d("Login_nya Sukses!", jsonObjectNya.toString());
					// simpan data yg di masukan pengguna
				//	SharedPreferences sharedPrefNya = PreferenceManager
						//	.getDefaultSharedPreferences(Login_Activity.this);
					//Editor editorNya = sharedPrefNya.edit();
					//editorNya.putString("nip", nip);
					//editorNya.putString("versi", kirim_versi);
					//editorNya.commit();
					 nip 			= jsonObjectNya.getString(TAG_NIP);
					 nama_pegawai 	= jsonObjectNya.getString(TAG_NAMA_PEGAWAI);
					 jabatan 		= jsonObjectNya.getString(TAG_JABATAN);
					 golongan 		= jsonObjectNya.getString(TAG_GOLONGAN);
					 password		= jsonObjectNya.getString(TAG_PASSWORD);


					if (cek_level == 1) {

						String pesan = "Untuk Dapat Menggunakan Aplikasi E-SPPD Dengan Menggunakan\nUser :"+nip+
								"Password :"+password+"\nAnda Perlu Menghubungi Pihak Administrator Untuk Mendapatkan Hak Akses Aplikasi E-SPPD";
						info(pesan);
/*
						SharedPreferences.Editor editor = sharedpreferences.edit();
						editor.putBoolean(session_status_level1, true);
						editor.putString(TAG_NIP, nip);
						editor.putString(TAG_NAMA_PEGAWAI, nama_pegawai);
						editor.putString(versi, kirim_versi);
						editor.commit();

						Intent intent = new Intent(Login_Activity.this,
								MainActivityBaru_Admin.class);
						//intent.putExtra(nippegawai, nip);

						intent.putExtra(TAG_NIP, nip);
						intent.putExtra(TAG_NAMA_PEGAWAI, nama_pegawai);
						intent.putExtra(versi, kirim_versi);
						finish();
						startActivity(intent);
						*/
					} else if (cek_level == 2) {

							SharedPreferences.Editor editor = sharedpreferences.edit();
							editor.putBoolean(session_status_level2, true);
							editor.putString(TAG_NIP, nip);
							editor.putString(TAG_NAMA_PEGAWAI, nama_pegawai);
							editor.putString(TAG_JABATAN, jabatan);
							editor.putString(TAG_GOLONGAN, golongan);
							editor.putString(TAG_PASSWORD, password);
							editor.putString(versi, kirim_versi);
							editor.commit();

							Intent intent = new Intent(Login_Activity.this,
									MainActivityBaru_Petugas.class);
							intent.putExtra(TAG_NIP, nip);
							intent.putExtra(TAG_NAMA_PEGAWAI, nama_pegawai);
							intent.putExtra(TAG_JABATAN, jabatan);
							intent.putExtra(TAG_GOLONGAN, golongan);
							intent.putExtra(TAG_PASSWORD, password);
							intent.putExtra(versi, kirim_versi);
							finish();
							startActivity(intent);

					}

					return jsonObjectNya.getString(TAG_PESAN2);
				} else {
					Log.d("Login_nya Gagal!",
							jsonObjectNya.getString(TAG_PESAN2));
					return jsonObjectNya.getString(TAG_PESAN2);
				}
			} catch (JSONException e) {
				responseString = e.toString();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				responseString = e.toString();
			}

			return responseString;
		}

		@Override
		protected void onPostExecute(String jawaban_json) {
			progressBarNya.dismiss();
			Log.e(TAG, "Respon Dari Server LOGIN ::: " + jawaban_json+" Error Data");
			String pesan1 = "java.lang.RuntimeException: Can't create handler inside thread";
			String nippegawai 	= edit_nip.getText().toString();
			String passpwgawai 	= edit_pass.getText().toString();
				if (jawaban_json != null) {
					if (jawaban_json.contains(pesan1)) {
						String pesan = "Untuk Dapat Menggunakan Aplikasi E-SPPD Dengan Menggunakan\nUser :" + nippegawai +
								"\nPassword :" + passpwgawai + "\nAnda Perlu Menghubungi Pihak Administrator Untuk " +
								"Mendapatkan Hak Akses Aplikasi E-SPPD";
						info(pesan);
					}else{
						Toast.makeText(getApplicationContext(), jawaban_json,
								Toast.LENGTH_LONG).show();
					}
				}

		}

	}

	private void show_warning(String message) {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setMessage(message)
				.setTitle("Peringatan")
				.setCancelable(false)
				.setIcon(R.drawable.ic_warning_black)
				.setPositiveButton("Coba Lagi",
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int id) {
								dialog.dismiss();
								refresh();
							}
						})
				.setNeutralButton("Keluar",
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int id) {
								dialog.dismiss();
								Login_Activity.this.finish();
								finish();
							}
						});
		AlertDialog alert = builder.create();
		alert.show();
	}
	private void info(String message) {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setMessage(message)
				.setTitle("Informasi")
				.setCancelable(false)
				.setIcon(R.drawable.ic_info_outline_24dp)
				.setPositiveButton("Ok",
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int id) {
								dialog.dismiss();								
							}
						});
		AlertDialog alert = builder.create();
		alert.show();
	}

	public void refresh() {
		finish();
		startActivity(getIntent());
	}

	/*
	 * private void login(final String nip, String pass) {
	 * 
	 * class LoginAsync extends AsyncTask<String, Void, String> {
	 * 
	 * private Dialog loadingDialog;
	 * 
	 * @Override protected void onPreExecute() { super.onPreExecute();
	 * loadingDialog = ProgressDialog.show(Login_Activity.this, "",
	 * "Loading..."); }
	 * 
	 * @Override protected String doInBackground(String... params) { String nip
	 * = params[0]; String pass = params[1];
	 * 
	 * 
	 * InputStream is = null; List<NameValuePair> nameValuePairs = new
	 * ArrayList<NameValuePair>(); nameValuePairs.add(new
	 * BasicNameValuePair("nip", nip)); nameValuePairs.add(new
	 * BasicNameValuePair("pass", pass));
	 * 
	 * String result = null; try {
	 * 
	 * HttpClient httpClient = new DefaultHttpClient(); HttpPost httpPost = new
	 * HttpPost( "http://edwin13530019.ml/sppd_rssm/cek_login.php");
	 * httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
	 * 
	 * HttpResponse response = httpClient.execute(httpPost);
	 * 
	 * 
	 * StatusLine status = response.getStatusLine(); if(status.getStatusCode()
	 * == HttpStatus.SC_OK && response != null){ HttpEntity entity =
	 * response.getEntity(); is = entity.getContent();
	 * 
	 * BufferedReader reader = new BufferedReader( new InputStreamReader(is,
	 * "UTF-8"), 8); StringBuilder sb = new StringBuilder();
	 * 
	 * String line = null; while ((line = reader.readLine()) != null) {
	 * sb.append(line + "\n"); } result = sb.toString(); is.close(); }else if
	 * (status.getStatusCode() == HttpStatus.SC_GATEWAY_TIMEOUT && response !=
	 * null) { Log.d(TAG, "Error"); }else{
	 * Toast.makeText(getApplicationContext(), "sasasasas", Toast.LENGTH_LONG)
	 * .show(); }
	 * 
	 * 
	 * } catch (ClientProtocolException e) { e.printStackTrace(); } catch
	 * (UnsupportedEncodingException e) { e.printStackTrace(); } catch
	 * (IOException e) { e.printStackTrace(); } return result; }
	 * 
	 * @Override protected void onPostExecute(String result) { //mPlayer = new
	 * Player(context,"");
	 * 
	 * // String s = result.trim();
	 * 
	 * loadingDialog.dismiss();
	 * 
	 * if (result != null && "success".equalsIgnoreCase(result)) {
	 * 
	 * Intent intent = new Intent(Login_Activity.this, MainActivityBaru_Admin.class);
	 * intent.putExtra(nippegawai, nip); finish(); startActivity(intent);
	 * 
	 * }else { Toast.makeText(getApplicationContext(),
	 * "Nomor Induk Pegawai dan Password Belum Benar", Toast.LENGTH_LONG)
	 * .show(); }
	 * 
	 * } } LoginAsync la = new LoginAsync(); la.execute(nip, pass);
	 * 
	 * }
	 */
	@Override
	public void onBackPressed() {
		infodialogback();
	}

	private void infodialogback() {
		AlertDialog.Builder ad = new AlertDialog.Builder(this);
		ad.setTitle("Informasi");
		ad.setMessage("Anda akan Keluar ?");
		ad.setIcon(R.drawable.ic_info_outline_24dp);
		ad.setPositiveButton("Ya", new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				Login_Activity.this.finish();
				finish();
			}
		});
		ad.setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		});
		ad.show();
	}

	public void setticker(LinearLayout parent_layout, String text,
						  Context Login) {
		if (text != "") {

			TextView view = new TextView(Login);
			view.setText(text);

			view.setTextColor(Color.BLACK);
			view.setTextSize(23.5F);
			Context context = view.getContext(); // gets the context of the view

			// measures the unconstrained size of the view
			// before it is drawn in the layout
			view.measure(View.MeasureSpec.UNSPECIFIED,
					View.MeasureSpec.UNSPECIFIED);

			// takes the unconstrained width of the view
			float width = view.getMeasuredWidth();
			float height = view.getMeasuredHeight();

			// gets the screen width
			@SuppressWarnings("deprecation")
			float screenWidth = ((Activity) context).getWindowManager()
					.getDefaultDisplay().getWidth();

			view.setLayoutParams(new LinearLayout.LayoutParams((int) width,
					(int) height, 1f));

			System.out.println("width and screenwidth are" + width + "/"
					+ screenWidth + "///" + view.getMeasuredWidth());

			// performs the calculation
			float toXDelta = width - (screenWidth - 0);

			// sets toXDelta to -300 if the text width is smaller that the
			// screen size
			if (toXDelta < 0) {
				toXDelta = 0 - screenWidth;// -300;
			} else {
				toXDelta = 0 - screenWidth - toXDelta;// -300 - toXDelta;
			}
			// Animation parameters
			Animation mAnimation = new TranslateAnimation(screenWidth,
					toXDelta, 0, 0);
			mAnimation.setDuration(15000);
			mAnimation.setRepeatMode(Animation.RESTART);
			mAnimation.setRepeatCount(Animation.INFINITE);
			view.setAnimation(mAnimation);
			parent_layout.addView(view);
		}
	}


}
