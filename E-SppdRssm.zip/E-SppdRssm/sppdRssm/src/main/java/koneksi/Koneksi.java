package koneksi;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;

import android.util.Log;

@SuppressWarnings("deprecation")
public class Koneksi {
	private final static String TAG = "Koneksi";
	// private final String serverUri =
	// "http://aplikasisppdrssm.pe.hu/sppd_rssm_apk";
	public static final String URL_WEBSITE = "http://sppdrssm.rssoedonomadiun.co.id/";
	private final String serverUri = "http://sppdrssm.rssoedonomadiun.co.id/sppd_rssm_apk";
    private static final String URL_SERVER = "http://sppdrssm.rssoedonomadiun.co.id/sppd_rssm_apk/";
    private static final String URL_SERVER2 = "http://sppdrssm.rssoedonomadiun.co.id/";

	public static final String tampil_data_nip 						= "tampil_data_nip.php";
	public static final String tampil_data_nip_spt 					= "tampil_data_nip_spt.php";
	public static final String tampil_data_nip_berdasarkan_spt 		= "tampil_data_nip_berdasarkan_spt.php";
	public static final String profil_pegawai 						= "profil_pegawai.php";
	public static final String search_nama_pegawai 					= "search_nama_pegawai.php";
	public static final String simpan_data_sppdbaru 				= "simpan_data_sppdbaru.php";
	public static final String tampil_daftar_sppd_per_nip 			= "tampil_daftar_sppd_per_nip.php";
	public static final String tampil_daftar_sppd_per_nip_HISTORY 	= "tampil_daftar_sppd_per_nip_HISTORY.php";
	public static final String tampil_daftar_sppd_per_nip_POSTING 	= "tampil_daftar_sppd_per_nip_POSTING.php";
	//public static final String download_spt 						= "print_spt2.php";
	public static final String tampil_daftar_edit_rincian 			= "tampil_daftar_edit_rincian.php";
	public static final String tampil_daftar_edit_riil 				= "tampil_daftar_edit_riil.php";


	public static final String IMAGE_DIRECTORY_NAME 				= "../Bukti E-SPPD";
    public static final String FILE_UPLOAD_URL 						=  URL_SERVER + "temp/Upload_Terbaru.php";
	public static final String hapus_data_per_riil					=  URL_SERVER + "hapus_file/hapus_data_per_riil.php";
	public static final String update_riil							=  URL_SERVER + "update_riil.php";
	public static final String tambah_uraian_riil					=  URL_SERVER + "tambah_uraian_riil.php";
	public static final String simpan_data_laporan_petugas 			=  URL_SERVER + "simpan_lap_perj.php";
	public static final String update_data_laporan_petugas 			=  URL_SERVER + "update_lap_perj.php";
	public static final String download_apk 						=  URL_SERVER2 + "Download_Apk/";
	public static final String LINK_UNTUK_LOGIN 					=  URL_SERVER + "login_nya.php";
	public static final String CEK_VERSI 							=  URL_SERVER + "cek_versi.php";
	public static final String simpan_pass 							=  URL_SERVER + "registrasi_pass_baru.php";
	public static final String simpan_update_data_rincian 			=  URL_SERVER + "simpan_data_rincian_biaya.php";
	public static final String hapus_data_rincian					=  URL_SERVER + "hapus_file/hapus_rincian.php";
	public static final String hapus_data_per_uraian			    =  URL_SERVER + "hapus_file/hapus_data_per_uraian.php";
    public static final String hapus_data_per_uraian_laporan	    =  URL_SERVER + "hapus_file/hapus_data_per_uraian_laporan.php";
    public static final String update_rincian_biaya 		        =  URL_SERVER + "update_rincian_biaya.php";
    public static final String download_spt 		                =  URL_SERVER + "prints/print_spt.php";
    public static final String download_sppd 	                    =  URL_SERVER + "prints/print_sppd.php";
    public static final String posting_url                          =  URL_SERVER + "posting_url.php";
	public static final String simpan_kritik 						=  URL_SERVER +"simpan_kritik.php";

	public static final String LINK_UNTUK_LOGIN_2 					=  URL_SERVER + "login_baru.php";
	public static final String LINK_UNTUK_LOGIN_TES					=  URL_SERVER + "login_baru_tes.php";

	public Koneksi() {
		super();
	}

	/* Mengirimkan GET request */
	public String sendGetRequest(String reqUrl) {
		HttpClient httpClient;
		//HttpGet httpGet = new HttpGet(serverUri + "/" + reqUrl);
        HttpGet httpGet = new HttpGet(URL_SERVER + reqUrl);
		InputStream is = null;
		StringBuilder stringBuilder = new StringBuilder();
		try {
			HttpParams params = new BasicHttpParams();
			HttpConnectionParams.setConnectionTimeout(params, 3000);
			HttpConnectionParams.setSoTimeout(params, 3000);
			httpClient = new DefaultHttpClient(params);
			Log.d(TAG, "executing...");
			HttpResponse httpResponse = httpClient.execute(httpGet);
			StatusLine status = httpResponse.getStatusLine();
			if (status.getStatusCode() == HttpStatus.SC_OK
					&& httpResponse != null) {
				/* mengambil response string dari server */
				HttpEntity httpEntity = httpResponse.getEntity();
				is = httpEntity.getContent();
				BufferedReader reader = new BufferedReader(
						new InputStreamReader(is));
				String line = null;
				while ((line = reader.readLine()) != null) {
					stringBuilder.append(line + "\n");
				}
				is.close();
			} else if (status.getStatusCode() == HttpStatus.SC_BAD_REQUEST
					&& httpResponse != null) {
				Log.d(TAG, "Error");
			}
		} catch (Exception e) {
			Log.d(TAG, e.getMessage());
		}

		return stringBuilder.toString();
	}

	public int sendPostRequest(Daftar_String Pegawai, String url) {
		int replyCode = 99;
		HttpClient httpClient;
		HttpPost post = new HttpPost(this.URL_SERVER + url);
		List<NameValuePair> value = new ArrayList<NameValuePair>();
		/* menambahkan parameter ke dalam request */

		value.add(new BasicNameValuePair("nip", Pegawai.getnip().toString()));
		value.add(new BasicNameValuePair("nama_pegawai", Pegawai
				.getnama_pegawai()));
		value.add(new BasicNameValuePair("jabatan", Pegawai.getjabatan()));
		value.add(new BasicNameValuePair("golongan", Pegawai.getgolongan()));

		try {
			HttpParams params = new BasicHttpParams();
			HttpConnectionParams.setConnectionTimeout(params, 3000);
			HttpConnectionParams.setSoTimeout(params, 3000);
			httpClient = new DefaultHttpClient(params);
			post.setEntity(new UrlEncodedFormEntity(value));
			Log.d(TAG, "executing post...");
			HttpResponse httpResponse = httpClient.execute(post);
			StatusLine status = httpResponse.getStatusLine();
			if (status.getStatusCode() == HttpStatus.SC_OK) {
				Log.d(TAG, "submitted sucessfully...");
				replyCode = status.getStatusCode();
			}
		} catch (IOException e) {
			Log.d(TAG, e.getMessage());
		}
		return replyCode;
	}
}
